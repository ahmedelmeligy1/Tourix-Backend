# Tourix Backend

Tourix Backend is a .NET MVC/Web API backend for the Tourix Flutter app. It uses SQL Server and EF Core.

## Architecture

```text
backend/
|-- Tourix.Backend.sln
`-- Tourix.Api/
    |-- Controllers/      # MVC API controllers
    |-- Application/      # Auth use cases and business flow
    |-- Contracts/        # Request/response DTOs used by Flutter
    |-- Database/         # EF Core DbContext, entities, and seed data
    |-- Domain/           # Core domain contracts
    |-- Infrastructure/   # SQL repositories, password hashing, token service
    `-- Program.cs        # Dependency injection and API startup
```

## Database

Default database name:

```text
TourixDb
```

Default connection string:

```text
Server=(localdb)\MSSQLLocalDB;Database=TourixDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True
```

If you use full SQL Server instead of LocalDB, update `backend/Tourix.Api/appsettings.json`:

```text
Server=localhost;Database=TourixDb;Trusted_Connection=True;TrustServerCertificate=True
```

The backend calls `Database.EnsureCreated()` on startup, then seeds realistic Tourix data from the requirements PDF:

- Admins
- Cities
- Places
- Media
- Trips
- TripPlaces
- QuestTemplates
- TripQuests
- Stickers
- Badges
- EgyptianPhrases
- QuizQuestions
- RewardItems
- Chat

There is also a starter SQL script:

```text
database/TourixDb.sql
```

## Run Backend

From the repo root:

```bash
dotnet restore backend\Tourix.Backend.sln --configfile NuGet.Config
dotnet run --project backend\Tourix.Api --urls http://localhost:5020
```

Open these URLs:

```text
http://localhost:5020/
http://localhost:5020/api/health
http://localhost:5020/api/catalog/bootstrap
```

## Flutter Integration

Flutter is configured to call:

```text
http://localhost:5020/api
```

Auth endpoints:

| Method | Endpoint | Body |
| --- | --- | --- |
| `POST` | `/api/auth/register` | `fullName`, `email`, `password` |
| `POST` | `/api/auth/login` | `email`, `password` |
| `POST` | `/api/auth/forgot-password` | `email` |
| `GET` | `/api/auth/me` | Bearer token header |

Catalog test endpoint:

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/api/catalog/bootstrap` | Confirms SQL seed data is loaded |

## Run Flutter With Backend

Keep the backend terminal open, then open a second terminal:

```bash
flutter run -d chrome
```

Register a new account from the Flutter signup screen. The user is saved in SQL Server, not memory.

## Android Emulator Note

For Android Emulator, change Flutter's API base URL from:

```text
http://localhost:5020/api
```

to:

```text
http://10.0.2.2:5020/api
```
