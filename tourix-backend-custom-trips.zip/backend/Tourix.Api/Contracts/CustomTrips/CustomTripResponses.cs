namespace Tourix.Api.Contracts.CustomTrips;

public sealed record CustomTripPlaceResponse(
    Guid PlaceId,
    string Name,
    string Description,
    string? CityName,
    int VisitOrder,
    DateOnly? PlannedVisitDate,
    int EstimatedDuration,
    string? CoverImage);

public sealed record CustomTripResponse(
    Guid Id,
    string Title,
    DateOnly? StartDate,
    DateOnly? EndDate,
    int TotalDays,
    string Status,
    DateTimeOffset CreatedAt,
    DateTimeOffset? UpdatedAt,
    IReadOnlyList<CustomTripPlaceResponse> Places);

public sealed record CustomTripResult<T>(T? Value, string? Error, int StatusCode)
{
    public bool Succeeded => Error is null;

    public static CustomTripResult<T> Success(T value) =>
        new(value, null, StatusCodes.Status200OK);

    public static CustomTripResult<T> Created(T value) =>
        new(value, null, StatusCodes.Status201Created);

    public static CustomTripResult<T> Failure(string error, int statusCode) =>
        new(default, error, statusCode);
}