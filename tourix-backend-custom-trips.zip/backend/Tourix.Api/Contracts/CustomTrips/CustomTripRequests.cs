using System.ComponentModel.DataAnnotations;

namespace Tourix.Api.Contracts.CustomTrips;

public sealed class CreateCustomTripRequest
{
    [Required]
    [StringLength(180, MinimumLength = 1)]
    public string? Title { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }
}

public sealed class UpdateCustomTripRequest
{
    [StringLength(180, MinimumLength = 1)]
    public string? Title { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }
}

public sealed class AddCustomTripPlaceRequest
{
    public Guid PlaceId { get; set; }
}

public sealed class ReorderCustomTripRequest
{
    [Required]
    public IReadOnlyList<Guid>? PlaceIds { get; set; }
}