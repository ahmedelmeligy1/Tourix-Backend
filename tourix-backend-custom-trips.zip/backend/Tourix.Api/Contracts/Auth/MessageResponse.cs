namespace Tourix.Api.Contracts.Auth;

public sealed record MessageResponse(string Message);
