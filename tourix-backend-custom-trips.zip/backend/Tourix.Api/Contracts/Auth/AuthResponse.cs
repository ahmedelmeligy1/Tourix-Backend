namespace Tourix.Api.Contracts.Auth;

public sealed record AuthResponse(string Token, UserProfileResponse User);
