namespace Tourix.Api.Contracts.Auth;

public sealed record SocialLoginRequest(string Provider, string Email, string FullName);
