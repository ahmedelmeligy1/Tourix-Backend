using Tourix.Api.Domain.Users;

namespace Tourix.Api.Contracts.Auth;

public sealed record UserProfileResponse(
    Guid Id,
    string FullName,
    string Email,
    int Level,
    int Xp,
    DateTimeOffset CreatedAt,
    DateTimeOffset? LastLoginAt)
{
    public static UserProfileResponse FromUser(User user) =>
        new(
            user.Id,
            user.FullName,
            user.Email,
            user.Level,
            user.Xp,
            user.CreatedAt,
            user.LastLoginAt);
}
