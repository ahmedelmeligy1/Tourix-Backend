namespace Tourix.Api.Contracts.Trips;

public sealed record TripSummaryResponse(
    Guid Id,
    string Title,
    string Description,
    string TripType,
    int EstimatedDuration,
    int TotalPoints,
    string Difficulty,
    string? CoverImage,
    int PlaceCount);

public sealed record TripPlaceResponse(
    int Order,
    Guid PlaceId,
    string Name,
    string Description,
    string? CityName,
    double Latitude,
    double Longitude,
    int EstimatedStayTime,
    int AverageVisitDuration,
    string? CoverImage);

public sealed record TripDetailsResponse(
    Guid Id,
    string Title,
    string Description,
    string TripType,
    int EstimatedDuration,
    int TotalPoints,
    string Difficulty,
    string? CoverImage,
    IReadOnlyList<TripPlaceResponse> Places);

public sealed record UserTripResponse(
    Guid UserTripId,
    Guid TripId,
    string Status,
    int Progress,
    DateTimeOffset? StartedAt,
    DateTimeOffset? CompletedAt,
    int EarnedPoints);

public sealed record CurrentTripResponse(
    UserTripResponse Trip,
    TripPlaceResponse? CurrentPlace,
    TripPlaceResponse? NextPlace,
    int PercentageCompleted);

public sealed record TripServiceResult<T>(T? Value, string? Error, int StatusCode)
{
    public bool Succeeded => Error is null;

    public static TripServiceResult<T> Success(T value) =>
        new(value, null, StatusCodes.Status200OK);

    public static TripServiceResult<T> Failure(string error, int statusCode) =>
        new(default, error, statusCode);
}