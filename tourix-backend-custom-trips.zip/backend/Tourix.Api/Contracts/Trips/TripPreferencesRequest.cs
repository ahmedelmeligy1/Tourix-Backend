namespace Tourix.Api.Contracts.Trips;

public sealed record BudgetRangeRequest(double Start, double End);

public sealed record TripPreferencesRequest(
    string? Destination,
    string? Duration,
    BudgetRangeRequest? BudgetRange,
    string TravelStyle,
    List<string> Interests);
