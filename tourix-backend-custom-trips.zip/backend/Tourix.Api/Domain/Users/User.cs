namespace Tourix.Api.Domain.Users;

public sealed class User
{
    private User()
    {
        FullName = string.Empty;
        Email = string.Empty;
        PasswordHash = string.Empty;
        AuthProvider = "Email";
        PreferredLanguage = "en";
        Status = "Active";
    }

    private User(
        Guid id,
        string fullName,
        string email,
        string passwordHash,
        DateTimeOffset createdAt)
    {
        Id = id;
        FullName = fullName;
        Email = email;
        PasswordHash = passwordHash;
        AuthProvider = "Email";
        PreferredLanguage = "en";
        Status = "Active";
        CreatedAt = createdAt;
        UpdatedAt = createdAt;
    }

    public Guid Id { get; private set; }

    public string FullName { get; private set; }

    public string Email { get; private set; }

    public string PasswordHash { get; private set; }

    public string AuthProvider { get; private set; }

    public string? Nationality { get; private set; }

    public string PreferredLanguage { get; private set; }

    public string? ProfileImage { get; private set; }

    public int TotalPoints { get; private set; }

    public int Level { get; private set; } = 1;

    public int Xp { get; private set; }

    public bool IsGuest { get; private set; }

    public string Status { get; private set; }

    public DateTimeOffset CreatedAt { get; private set; }

    public DateTimeOffset? LastLoginAt { get; private set; }

    public DateTimeOffset? UpdatedAt { get; private set; }

    public static User Create(string fullName, string email, string passwordHash) =>
        new(Guid.NewGuid(), fullName, email, passwordHash, DateTimeOffset.UtcNow);

    public void MarkLoggedIn()
    {
        LastLoginAt = DateTimeOffset.UtcNow;
        UpdatedAt = DateTimeOffset.UtcNow;
    }

    public void AwardPoints(int points)
    {
        if (points < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(points), "Points cannot be negative.");
        }

        TotalPoints += points;
        Xp += points;
        Level = Math.Max(Level, 1 + (TotalPoints / 1000));
        UpdatedAt = DateTimeOffset.UtcNow;
    }
}
