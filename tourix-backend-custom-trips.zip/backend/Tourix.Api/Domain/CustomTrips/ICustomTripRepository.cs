using Tourix.Api.Database.Entities;

namespace Tourix.Api.Domain.CustomTrips;

public interface ICustomTripRepository
{
    Task<CustomTrip?> GetAsync(
        Guid userId,
        Guid customTripId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<CustomTrip>> GetByUserAsync(
        Guid userId,
        CancellationToken cancellationToken);

    Task<Place?> GetPlaceAsync(
        Guid placeId,
        CancellationToken cancellationToken);

    Task<bool> CustomTripPlaceExistsAsync(
        Guid customTripId,
        Guid placeId,
        CancellationToken cancellationToken);

    Task<int> GetNextVisitOrderAsync(
        Guid customTripId,
        CancellationToken cancellationToken);

    Task AddAsync(CustomTrip customTrip, CancellationToken cancellationToken);

    Task AddPlaceAsync(
        CustomTripPlace customTripPlace,
        CancellationToken cancellationToken);

    Task RemovePlaceAsync(
        CustomTripPlace customTripPlace,
        CancellationToken cancellationToken);

    Task UpdateAsync(CustomTrip customTrip, CancellationToken cancellationToken);

    Task DeleteAsync(CustomTrip customTrip, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);

    Task ReorderAsync(
        Guid customTripId,
        IReadOnlyList<Guid> placeIds,
        CancellationToken cancellationToken);
}