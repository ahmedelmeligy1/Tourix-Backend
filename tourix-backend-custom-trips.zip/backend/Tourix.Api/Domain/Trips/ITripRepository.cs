using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Domain.Trips;

public interface ITripRepository
{
    Task<IReadOnlyList<Trip>> GetPublishedTripsAsync(CancellationToken cancellationToken);

    Task<Trip?> GetPublishedTripAsync(Guid tripId, CancellationToken cancellationToken);

    Task<UserTrip?> GetUserTripAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken);

    Task<UserTrip?> GetCurrentUserTripAsync(
        Guid userId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<UserTrip>> GetUserTripsAsync(
        Guid userId,
        CancellationToken cancellationToken);

    Task<User?> GetUserAsync(Guid userId, CancellationToken cancellationToken);

    Task<bool> UserTripExistsAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<int>> GetVerifiedVisitOrdersAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<Guid>> GetVerifiedVisitPlaceIdsAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<Guid>> GetRequiredQuestIdsAsync(
        Guid tripId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<Guid>> GetCompletedQuestIdsAsync(
        Guid userId,
        IReadOnlyCollection<Guid> questIds,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<Badge>> GetEligibleBadgesAsync(
        Guid userId,
        int totalPointsAfterTrip,
        CancellationToken cancellationToken);

    Task StartUserTripAsync(UserTrip userTrip, CancellationToken cancellationToken);

    Task<bool> CompleteUserTripAsync(
        Guid userId,
        Guid tripId,
        int points,
        IReadOnlyCollection<Badge> badges,
        DateTimeOffset completedAt,
        CancellationToken cancellationToken);
}