using Tourix.Api.Database.Entities;

namespace Tourix.Api.Database;

public static class TourixDbSeeder
{
    private static readonly Guid AdminId = Guid.Parse("11111111-1111-1111-1111-111111111111");
    private static readonly Guid CairoId = Guid.Parse("22222222-2222-2222-2222-222222222221");
    private static readonly Guid GizaId = Guid.Parse("22222222-2222-2222-2222-222222222222");
    private static readonly Guid LuxorId = Guid.Parse("22222222-2222-2222-2222-222222222223");
    private static readonly Guid AswanId = Guid.Parse("22222222-2222-2222-2222-222222222224");

    public static async Task SeedAsync(TourixDbContext dbContext)
    {
        if (dbContext.Cities.Any())
        {
            return;
        }

        var now = DateTimeOffset.UtcNow;

        dbContext.Admins.Add(new Admin
        {
            AdminId = AdminId,
            FullName = "Tourix Content Admin",
            Email = "admin@tourix.app",
            Password = "seeded-admin-password-placeholder",
            Role = "SuperAdmin",
            Status = "Active",
            CreatedAt = now,
        });

        dbContext.Cities.AddRange(
            City(CairoId, "Cairo", "Egypt's capital and the gateway to Islamic Cairo, museums, and urban discovery."),
            City(GizaId, "Giza", "Home of the pyramids, the Sphinx, and unforgettable desert heritage."),
            City(LuxorId, "Luxor", "The world's open-air museum with temples, tombs, and Nile-side culture."),
            City(AswanId, "Aswan", "A calm Nubian city with islands, temples, and golden Nile sunsets."));

        var places = new[]
        {
            Place("33333333-3333-3333-3333-333333333331", GizaId, "Pyramids of Giza", "Explore the Great Pyramid complex and the ancient royal necropolis.", 29.9792, 31.1342, "Historical", 540),
            Place("33333333-3333-3333-3333-333333333332", GizaId, "Great Sphinx", "Stand beside Egypt's iconic limestone guardian.", 29.9753, 31.1376, "Historical", 240),
            Place("33333333-3333-3333-3333-333333333333", CairoId, "Egyptian Museum", "Discover royal mummies, ancient artifacts, and pharaonic treasures.", 30.0478, 31.2336, "Museum", 300),
            Place("33333333-3333-3333-3333-333333333334", CairoId, "Khan El Khalili", "Walk through historic markets, crafts, and local food stops.", 30.0477, 31.2625, "Entertainment", 0),
            Place("33333333-3333-3333-3333-333333333335", LuxorId, "Karnak Temple", "Visit one of Egypt's largest religious complexes.", 25.7188, 32.6573, "Historical", 450),
            Place("33333333-3333-3333-3333-333333333336", LuxorId, "Valley of the Kings", "Enter royal tombs carved into Luxor's western mountains.", 25.7402, 32.6014, "Historical", 750),
            Place("33333333-3333-3333-3333-333333333337", AswanId, "Philae Temple", "A temple island dedicated to Isis and rescued from Nile flooding.", 24.0253, 32.8843, "Historical", 450),
            Place("33333333-3333-3333-3333-333333333338", AswanId, "Nubian Village", "Experience colorful homes, Nubian hospitality, and local culture.", 24.0889, 32.8897, "Cultural", 120),
        };

        dbContext.Places.AddRange(places);
        dbContext.Media.AddRange(places.Select(place => new Media
        {
            MediaId = Guid.NewGuid(),
            PlaceId = place.PlaceId,
            Url = place.CoverImage ?? string.Empty,
            MediaType = "Image",
            IsCover = true,
            UploadedAt = now,
            UploadedByAdminId = AdminId,
        }));

        var egyptIconsTripId = Guid.Parse("44444444-4444-4444-4444-444444444441");
        var nileLegacyTripId = Guid.Parse("44444444-4444-4444-4444-444444444442");
        dbContext.Trips.AddRange(
            Trip(egyptIconsTripId, "Egypt Icons Sprint", "A fast cultural route through Cairo and Giza highlights.", "Cultural", 2, 900),
            Trip(nileLegacyTripId, "Nile Legacy Trail", "A deeper heritage route through Luxor and Aswan.", "Mixed", 5, 1800));

        dbContext.TripPlaces.AddRange(
            TripPlace(egyptIconsTripId, places[0].PlaceId, 1, 180),
            TripPlace(egyptIconsTripId, places[1].PlaceId, 2, 60),
            TripPlace(egyptIconsTripId, places[2].PlaceId, 3, 150),
            TripPlace(nileLegacyTripId, places[4].PlaceId, 1, 180),
            TripPlace(nileLegacyTripId, places[5].PlaceId, 2, 240),
            TripPlace(nileLegacyTripId, places[6].PlaceId, 3, 160),
            TripPlace(nileLegacyTripId, places[7].PlaceId, 4, 120));

        var photoQuestId = Guid.Parse("55555555-5555-5555-5555-555555555551");
        var quizQuestId = Guid.Parse("55555555-5555-5555-5555-555555555552");
        dbContext.QuestTemplates.AddRange(
            new QuestTemplate { QuestTemplateId = photoQuestId, Title = "Landmark Proof", Description = "Capture a clear photo of the landmark from the main viewpoint.", QuestType = "TakePhoto", RewardPoints = 120, RequiredPhotos = 1, DifficultyLevel = "Easy", Status = "Active", CreatedAt = now },
            new QuestTemplate { QuestTemplateId = quizQuestId, Title = "History Check", Description = "Answer a short question about the place you are visiting.", QuestType = "Quiz", RewardPoints = 80, RequiredPhotos = 0, DifficultyLevel = "Easy", Status = "Active", CreatedAt = now });

        dbContext.TripQuests.AddRange(places.Take(6).Select((place, index) => new TripQuest
        {
            TripQuestId = Guid.NewGuid(),
            ContextType = "Trip",
            ContextId = index < 3 ? egyptIconsTripId : nileLegacyTripId,
            PlaceId = place.PlaceId,
            QuestTemplateId = index % 2 == 0 ? photoQuestId : quizQuestId,
            Status = "Active",
        }));

        dbContext.Stickers.AddRange(
            Sticker("Pyramid Spark", "Landmarks", "Common"),
            Sticker("Nile Wave", "Culture", "Rare"),
            Sticker("Koshary Bowl", "Food", "Epic"));

        dbContext.Badges.AddRange(
            Badge("First Check-in", "Complete your first verified visit.", 100, "Explorer"),
            Badge("Temple Seeker", "Complete three temple quests.", 700, "Explorer"),
            Badge("Photo Oracle", "Upload five approved landmark photos.", 1200, "Photographer"));

        var phraseId = Guid.Parse("66666666-6666-6666-6666-666666666661");
        dbContext.EgyptianPhrases.AddRange(
            new EgyptianPhrase { PhraseId = phraseId, ArabicText = "شكرا", EnglishTranslation = "Thank you", Pronunciation = "Shokran", DifficultyLevel = "Easy", UnlockPoints = 0, CreatedAt = now },
            new EgyptianPhrase { PhraseId = Guid.NewGuid(), ArabicText = "بكام؟", EnglishTranslation = "How much?", Pronunciation = "Bikam?", DifficultyLevel = "Easy", UnlockPoints = 50, CreatedAt = now },
            new EgyptianPhrase { PhraseId = Guid.NewGuid(), ArabicText = "فين المتحف؟", EnglishTranslation = "Where is the museum?", Pronunciation = "Fein el mathaf?", DifficultyLevel = "Medium", UnlockPoints = 100, CreatedAt = now });

        dbContext.QuizQuestions.Add(new QuizQuestion
        {
            QuestionId = Guid.NewGuid(),
            PhraseId = phraseId,
            QuestionText = "What does Shokran mean?",
            CorrectAnswer = "Thank you",
            WrongAnswer1 = "Good morning",
            WrongAnswer2 = "How much?",
            RewardPoints = 25,
            CreatedAt = now,
        });

        dbContext.RewardItems.AddRange(
            Reward("Museum Cafe Discount", "Discount", "Egyptian Museum Cafe", 300, 50),
            Reward("Nile Felucca Voucher", "Voucher", "Aswan River Partners", 900, 20),
            Reward("Tourix Sticker Pack", "Merchandise", "Tourix", 500, 100));

        dbContext.Chats.Add(new Chat
        {
            ChatId = Guid.NewGuid(),
            Name = "Tourix Egypt Explorers",
            ChatType = "Public",
            IsPrivate = false,
            CreatedAt = now,
            CreatedBy = AdminId,
        });

        await dbContext.SaveChangesAsync();
    }

    private static City City(Guid id, string name, string description) => new()
    {
        CityId = id,
        Name = name,
        Description = description,
        CoverImage = $"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?tourix={Uri.EscapeDataString(name)}",
        Country = "Egypt",
        CreatedAt = DateTimeOffset.UtcNow,
    };

    private static Place Place(string id, Guid cityId, string name, string description, double latitude, double longitude, string category, decimal ticketPrice) => new()
    {
        PlaceId = Guid.Parse(id),
        CityId = cityId,
        Name = name,
        Description = description,
        Latitude = latitude,
        Longitude = longitude,
        GeofenceRadius = 120,
        AverageVisitDuration = 120,
        TicketPrice = ticketPrice,
        OpeningHours = new TimeOnly(8, 0),
        ClosingHours = new TimeOnly(17, 0),
        Category = category,
        CoverImage = $"https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?tourix={Uri.EscapeDataString(name)}",
        Status = "Active",
        CreatedByAdminId = AdminId,
        UpdatedByAdminId = AdminId,
        CreatedAt = DateTimeOffset.UtcNow,
    };

    private static Trip Trip(Guid id, string title, string description, string tripType, int days, int points) => new()
    {
        TripId = id,
        Title = title,
        Description = description,
        TripType = tripType,
        EstimatedDuration = days,
        TotalPoints = points,
        DifficultyLevel = days <= 2 ? "Easy" : "Medium",
        CoverImage = "https://images.unsplash.com/photo-1553913861-c0fddf2619ee",
        Status = "Published",
        CreatedByAdminId = AdminId,
        UpdatedByAdminId = AdminId,
        CreatedAt = DateTimeOffset.UtcNow,
    };

    private static TripPlace TripPlace(Guid tripId, Guid placeId, int order, int stayTime) => new()
    {
        TripPlaceId = Guid.NewGuid(),
        TripId = tripId,
        PlaceId = placeId,
        VisitOrder = order,
        EstimatedStayTime = stayTime,
    };

    private static Sticker Sticker(string name, string category, string rarity) => new()
    {
        StickerId = Guid.NewGuid(),
        Name = name,
        ImageUrl = $"https://cdn.tourix.local/stickers/{name.Replace(' ', '-').ToLowerInvariant()}.png",
        Category = category,
        UnlockCondition = "Complete related discovery activity.",
        Rarity = rarity,
        CreatedAt = DateTimeOffset.UtcNow,
    };

    private static Badge Badge(string name, string description, int requiredPoints, string category) => new()
    {
        BadgeId = Guid.NewGuid(),
        Name = name,
        Description = description,
        Icon = $"https://cdn.tourix.local/badges/{name.Replace(' ', '-').ToLowerInvariant()}.png",
        RequiredPoints = requiredPoints,
        Category = category,
        CreatedAt = DateTimeOffset.UtcNow,
    };

    private static RewardItem Reward(string title, string type, string partner, int pointsCost, int stock) => new()
    {
        RewardId = Guid.NewGuid(),
        Title = title,
        Description = $"Redeem points for {title}.",
        RewardType = type,
        ImageUrl = "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9",
        PointsCost = pointsCost,
        PartnerName = partner,
        Stock = stock,
        ValidUntil = DateOnly.FromDateTime(DateTime.UtcNow.AddMonths(6)),
        Status = "Active",
        CreatedAt = DateTimeOffset.UtcNow,
    };
}
