using Tourix.Api.Domain.Users;

namespace Tourix.Api.Database.Entities;

public sealed class Admin
{
    public Guid AdminId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Role { get; set; } = "ContentManager";
    public string Status { get; set; } = "Active";
    public DateTimeOffset? LastLogin { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
}

public sealed class City
{
    public Guid CityId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? CoverImage { get; set; }
    public string Country { get; set; } = "Egypt";
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public ICollection<Place> Places { get; set; } = new List<Place>();
}

public sealed class Place
{
    public Guid PlaceId { get; set; }
    public Guid CityId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public int GeofenceRadius { get; set; }
    public int AverageVisitDuration { get; set; }
    public decimal TicketPrice { get; set; }
    public TimeOnly OpeningHours { get; set; }
    public TimeOnly ClosingHours { get; set; }
    public string Category { get; set; } = "Historical";
    public string? CoverImage { get; set; }
    public string Status { get; set; } = "Active";
    public Guid CreatedByAdminId { get; set; }
    public Guid? UpdatedByAdminId { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public City? City { get; set; }
    public Admin? CreatedByAdmin { get; set; }
    public Admin? UpdatedByAdmin { get; set; }
    public ICollection<Media> Media { get; set; } = new List<Media>();
}

public sealed class Media
{
    public Guid MediaId { get; set; }
    public Guid PlaceId { get; set; }
    public string Url { get; set; } = string.Empty;
    public string MediaType { get; set; } = "Image";
    public bool IsCover { get; set; }
    public DateTimeOffset UploadedAt { get; set; }
    public Guid UploadedByAdminId { get; set; }
    public Place? Place { get; set; }
}

public sealed class Trip
{
    public Guid TripId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string TripType { get; set; } = "Cultural";
    public int EstimatedDuration { get; set; }
    public int TotalPoints { get; set; }
    public string DifficultyLevel { get; set; } = "Easy";
    public string? CoverImage { get; set; }
    public string Status { get; set; } = "Published";
    public Guid CreatedByAdminId { get; set; }
    public Guid? UpdatedByAdminId { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public ICollection<TripPlace> TripPlaces { get; set; } = new List<TripPlace>();
}

public sealed class TripPlace
{
    public Guid TripPlaceId { get; set; }
    public Guid TripId { get; set; }
    public Guid PlaceId { get; set; }
    public int VisitOrder { get; set; }
    public int EstimatedStayTime { get; set; }
    public Trip? Trip { get; set; }
    public Place? Place { get; set; }
}

public sealed class UserTrip
{
    public Guid UserTripId { get; set; }
    public Guid UserId { get; set; }
    public Guid TripId { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public int ProgressPercentage { get; set; }
    public int TotalEarnedPoints { get; set; }
    public string Status { get; set; } = "NotStarted";
    public Trip? Trip { get; set; }
}

public sealed class QuestTemplate
{
    public Guid QuestTemplateId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string QuestType { get; set; } = "TakePhoto";
    public int RewardPoints { get; set; }
    public int RequiredPhotos { get; set; }
    public string DifficultyLevel { get; set; } = "Easy";
    public int? TimeLimit { get; set; }
    public string Status { get; set; } = "Active";
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
}

public sealed class TripQuest
{
    public Guid TripQuestId { get; set; }
    public string ContextType { get; set; } = "Trip";
    public Guid ContextId { get; set; }
    public Guid PlaceId { get; set; }
    public Guid QuestTemplateId { get; set; }
    public string Status { get; set; } = "Active";
    public Place? Place { get; set; }
    public QuestTemplate? QuestTemplate { get; set; }
}

public sealed class UserQuest
{
    public Guid UserQuestId { get; set; }
    public Guid UserId { get; set; }
    public Guid TripQuestId { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public int ProgressPercentage { get; set; }
    public int EarnedPoints { get; set; }
    public string Status { get; set; } = "NotStarted";
}

public sealed class SavedPlace
{
    public Guid SavedPlaceId { get; set; }
    public Guid UserId { get; set; }
    public Guid PlaceId { get; set; }
    public DateTimeOffset SavedAt { get; set; }
}

public sealed class CustomTrip
{
    public Guid CustomTripId { get; set; }
    public Guid UserId { get; set; }
    public string Title { get; set; } = string.Empty;
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public int TotalDays { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public ICollection<CustomTripPlace> Places { get; set; } = new List<CustomTripPlace>();
}

public sealed class CustomTripPlace
{
    public Guid CustomTripPlaceId { get; set; }
    public Guid CustomTripId { get; set; }
    public Guid PlaceId { get; set; }
    public int VisitOrder { get; set; }
    public DateOnly? PlannedVisitDate { get; set; }
    public int EstimatedDuration { get; set; }
    public CustomTrip? CustomTrip { get; set; }
    public Place? Place { get; set; }
}

public sealed class Visit
{
    public Guid VisitId { get; set; }
    public Guid UserId { get; set; }
    public Guid PlaceId { get; set; }
    public Guid? TripId { get; set; }
    public Guid? CustomTripId { get; set; }
    public Guid? TripQuestId { get; set; }
    public int RouteOrder { get; set; }
    public DateOnly VisitDate { get; set; }
    public string VerificationStatus { get; set; } = "Pending";
    public int EarnedPoints { get; set; }
    public DateTimeOffset? CheckInTime { get; set; }
    public DateTimeOffset? CheckOutTime { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class VisitPhoto
{
    public Guid PhotoId { get; set; }
    public Guid VisitId { get; set; }
    public string ImageUrl { get; set; } = string.Empty;
    public string CaptureAngle { get; set; } = "Front";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public DateTimeOffset CapturedAt { get; set; }
    public string ValidationStatus { get; set; } = "Pending";
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class AIVerification
{
    public Guid VerificationId { get; set; }
    public Guid PhotoId { get; set; }
    public string DetectedLandmark { get; set; } = string.Empty;
    public double ConfidenceScore { get; set; }
    public string ValidationResult { get; set; } = "Pending";
    public string? ValidationNotes { get; set; }
    public Guid? ReviewedByAdminId { get; set; }
    public DateTimeOffset? ReviewedAt { get; set; }
    public DateTimeOffset? VerifiedAt { get; set; }
}

public sealed class Review
{
    public Guid ReviewId { get; set; }
    public Guid UserId { get; set; }
    public Guid PlaceId { get; set; }
    public Guid VisitId { get; set; }
    public int Rating { get; set; }
    public string? Comment { get; set; }
    public int HelpfulCount { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class PermitRequest
{
    public Guid PermitRequestId { get; set; }
    public Guid UserId { get; set; }
    public Guid PlaceId { get; set; }
    public string PermitType { get; set; } = string.Empty;
    public string Purpose { get; set; } = string.Empty;
    public DateOnly RequestDate { get; set; }
    public string Status { get; set; } = "Submitted";
    public string? ReviewNotes { get; set; }
    public string? AttachmentUrl { get; set; }
    public Guid? ReviewedByAdminId { get; set; }
    public DateTimeOffset? ReviewedAt { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class Chat { public Guid ChatId { get; set; } public string Name { get; set; } = string.Empty; public string ChatType { get; set; } = "Public"; public bool IsPrivate { get; set; } public DateTimeOffset CreatedAt { get; set; } public Guid CreatedBy { get; set; } }
public sealed class ChatMember { public Guid ChatMemberId { get; set; } public Guid ChatId { get; set; } public Guid UserId { get; set; } public DateTimeOffset JoinedAt { get; set; } public string Role { get; set; } = "Member"; }
public sealed class Message { public Guid MessageId { get; set; } public Guid ChatId { get; set; } public Guid UserId { get; set; } public string? MessageText { get; set; } public string? MediaUrl { get; set; } public Guid? StickerId { get; set; } public string MessageType { get; set; } = "Text"; public DateTimeOffset SentAt { get; set; } public DateTimeOffset CreatedAt { get; set; } }
public sealed class Report { public Guid ReportId { get; set; } public Guid ReporterUserId { get; set; } public Guid ReportedUserId { get; set; } public Guid? MessageId { get; set; } public string Reason { get; set; } = string.Empty; public string Status { get; set; } = "Open"; public Guid? ResolvedByAdminId { get; set; } public DateTimeOffset? ResolvedAt { get; set; } public DateTimeOffset CreatedAt { get; set; } }
public sealed class Block { public Guid BlockId { get; set; } public Guid BlockerUserId { get; set; } public Guid BlockedUserId { get; set; } public DateTimeOffset CreatedAt { get; set; } }
public sealed class DeviceToken { public Guid DeviceTokenId { get; set; } public Guid UserId { get; set; } public string Token { get; set; } = string.Empty; public string Platform { get; set; } = "Android"; public DateTimeOffset LastUsedAt { get; set; } public DateTimeOffset CreatedAt { get; set; } }
public sealed class Sticker { public Guid StickerId { get; set; } public string Name { get; set; } = string.Empty; public string ImageUrl { get; set; } = string.Empty; public string Category { get; set; } = "Culture"; public string UnlockCondition { get; set; } = string.Empty; public string Rarity { get; set; } = "Common"; public DateTimeOffset CreatedAt { get; set; } public DateTimeOffset? UpdatedAt { get; set; } }
public sealed class UserSticker { public Guid UserStickerId { get; set; } public Guid UserId { get; set; } public Guid StickerId { get; set; } public DateTimeOffset UnlockedAt { get; set; } public string Status { get; set; } = "Unlocked"; }
public sealed class Badge { public Guid BadgeId { get; set; } public string Name { get; set; } = string.Empty; public string Description { get; set; } = string.Empty; public string Icon { get; set; } = string.Empty; public int RequiredPoints { get; set; } public string Category { get; set; } = "Explorer"; public DateTimeOffset CreatedAt { get; set; } public DateTimeOffset? UpdatedAt { get; set; } }
public sealed class UserBadge { public Guid UserBadgeId { get; set; } public Guid UserId { get; set; } public Guid BadgeId { get; set; } public DateTimeOffset EarnedDate { get; set; } public string Status { get; set; } = "Earned"; }
public sealed class EgyptianPhrase { public Guid PhraseId { get; set; } public string ArabicText { get; set; } = string.Empty; public string EnglishTranslation { get; set; } = string.Empty; public string Pronunciation { get; set; } = string.Empty; public string DifficultyLevel { get; set; } = "Easy"; public int UnlockPoints { get; set; } public DateTimeOffset CreatedAt { get; set; } public DateTimeOffset? UpdatedAt { get; set; } }
public sealed class UserPhrase { public Guid UserPhraseId { get; set; } public Guid UserId { get; set; } public Guid PhraseId { get; set; } public DateTimeOffset UnlockedAt { get; set; } public string Status { get; set; } = "Unlocked"; }
public sealed class QuizQuestion { public Guid QuestionId { get; set; } public Guid PhraseId { get; set; } public string QuestionText { get; set; } = string.Empty; public string CorrectAnswer { get; set; } = string.Empty; public string WrongAnswer1 { get; set; } = string.Empty; public string WrongAnswer2 { get; set; } = string.Empty; public int RewardPoints { get; set; } public DateTimeOffset CreatedAt { get; set; } public DateTimeOffset? UpdatedAt { get; set; } }
public sealed class RewardItem { public Guid RewardId { get; set; } public string Title { get; set; } = string.Empty; public string Description { get; set; } = string.Empty; public string RewardType { get; set; } = "Voucher"; public string? ImageUrl { get; set; } public int PointsCost { get; set; } public string PartnerName { get; set; } = string.Empty; public int Stock { get; set; } public DateOnly? ValidUntil { get; set; } public string Status { get; set; } = "Active"; public DateTimeOffset CreatedAt { get; set; } public DateTimeOffset? UpdatedAt { get; set; } }
public sealed class RewardRedemption { public Guid RedemptionId { get; set; } public Guid UserId { get; set; } public Guid RewardId { get; set; } public DateTimeOffset RedeemedAt { get; set; } public string RedemptionCode { get; set; } = string.Empty; public int PointsSpent { get; set; } public string Status { get; set; } = "Pending"; public DateTimeOffset CreatedAt { get; set; } }
public sealed class Notification { public Guid NotificationId { get; set; } public Guid UserId { get; set; } public string Title { get; set; } = string.Empty; public string Body { get; set; } = string.Empty; public string Type { get; set; } = "System"; public string? RelatedEntityType { get; set; } public Guid? RelatedEntityId { get; set; } public bool IsRead { get; set; } public DateTimeOffset CreatedAt { get; set; } }
public sealed class PointTransaction { public Guid TransactionId { get; set; } public Guid UserId { get; set; } public string SourceType { get; set; } = string.Empty; public Guid? SourceId { get; set; } public int Points { get; set; } public string TransactionType { get; set; } = "Earn"; public string Description { get; set; } = string.Empty; public int BalanceAfterTransaction { get; set; } public DateTimeOffset CreatedAt { get; set; } }
