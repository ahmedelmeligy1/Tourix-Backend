using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Database;

public sealed class TourixDbContext(DbContextOptions<TourixDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Admin> Admins => Set<Admin>();
    public DbSet<City> Cities => Set<City>();
    public DbSet<Place> Places => Set<Place>();
    public DbSet<Media> Media => Set<Media>();
    public DbSet<Trip> Trips => Set<Trip>();
    public DbSet<TripPlace> TripPlaces => Set<TripPlace>();
    public DbSet<UserTrip> UserTrips => Set<UserTrip>();
    public DbSet<QuestTemplate> QuestTemplates => Set<QuestTemplate>();
    public DbSet<TripQuest> TripQuests => Set<TripQuest>();
    public DbSet<UserQuest> UserQuests => Set<UserQuest>();
    public DbSet<SavedPlace> SavedPlaces => Set<SavedPlace>();
    public DbSet<CustomTrip> CustomTrips => Set<CustomTrip>();
    public DbSet<CustomTripPlace> CustomTripPlaces => Set<CustomTripPlace>();
    public DbSet<Visit> Visits => Set<Visit>();
    public DbSet<VisitPhoto> VisitPhotos => Set<VisitPhoto>();
    public DbSet<AIVerification> AIVerifications => Set<AIVerification>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<PermitRequest> PermitRequests => Set<PermitRequest>();
    public DbSet<Chat> Chats => Set<Chat>();
    public DbSet<ChatMember> ChatMembers => Set<ChatMember>();
    public DbSet<Message> Messages => Set<Message>();
    public DbSet<Report> Reports => Set<Report>();
    public DbSet<Block> Blocks => Set<Block>();
    public DbSet<DeviceToken> DeviceTokens => Set<DeviceToken>();
    public DbSet<Sticker> Stickers => Set<Sticker>();
    public DbSet<UserSticker> UserStickers => Set<UserSticker>();
    public DbSet<Badge> Badges => Set<Badge>();
    public DbSet<UserBadge> UserBadges => Set<UserBadge>();
    public DbSet<EgyptianPhrase> EgyptianPhrases => Set<EgyptianPhrase>();
    public DbSet<UserPhrase> UserPhrases => Set<UserPhrase>();
    public DbSet<QuizQuestion> QuizQuestions => Set<QuizQuestion>();
    public DbSet<RewardItem> RewardItems => Set<RewardItem>();
    public DbSet<RewardRedemption> RewardRedemptions => Set<RewardRedemption>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<PointTransaction> PointTransactions => Set<PointTransaction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureUsers(modelBuilder);
        ConfigureCatalog(modelBuilder);
        ConfigureTrips(modelBuilder);
        ConfigureEngagement(modelBuilder);
    }

    private static void ConfigureUsers(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("Users");
            entity.HasKey(user => user.Id);
            entity.Property(user => user.Id).HasColumnName("UserId");
            entity.Property(user => user.FullName).HasMaxLength(160).IsRequired();
            entity.Property(user => user.Email).HasMaxLength(256).IsRequired();
            entity.HasIndex(user => user.Email).IsUnique();
            entity.Property(user => user.PasswordHash).HasMaxLength(512).IsRequired();
            entity.Property(user => user.AuthProvider).HasMaxLength(40).IsRequired();
            entity.Property(user => user.Nationality).HasMaxLength(80);
            entity.Property(user => user.PreferredLanguage).HasMaxLength(12).IsRequired();
            entity.Property(user => user.ProfileImage).HasMaxLength(600);
            entity.Property(user => user.Status).HasMaxLength(40).IsRequired();
        });

        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(admin => admin.AdminId);
            entity.HasIndex(admin => admin.Email).IsUnique();
            entity.Property(admin => admin.FullName).HasMaxLength(160).IsRequired();
            entity.Property(admin => admin.Email).HasMaxLength(256).IsRequired();
            entity.Property(admin => admin.Password).HasMaxLength(512).IsRequired();
            entity.Property(admin => admin.Role).HasMaxLength(40).IsRequired();
            entity.Property(admin => admin.Status).HasMaxLength(40).IsRequired();
        });
    }

    private static void ConfigureCatalog(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<City>(entity =>
        {
            entity.HasKey(city => city.CityId);
            entity.Property(city => city.Name).HasMaxLength(120).IsRequired();
            entity.Property(city => city.Country).HasMaxLength(80).IsRequired();
        });

        modelBuilder.Entity<Place>(entity =>
        {
            entity.HasKey(place => place.PlaceId);
            entity.Property(place => place.Name).HasMaxLength(180).IsRequired();
            entity.Property(place => place.Category).HasMaxLength(60).IsRequired();
            entity.Property(place => place.Status).HasMaxLength(40).IsRequired();
            entity.Property(place => place.TicketPrice).HasColumnType("decimal(10,2)");
            entity.HasOne(place => place.City).WithMany(city => city.Places).HasForeignKey(place => place.CityId);
            entity.HasOne(place => place.CreatedByAdmin).WithMany().HasForeignKey(place => place.CreatedByAdminId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(place => place.UpdatedByAdmin).WithMany().HasForeignKey(place => place.UpdatedByAdminId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Media>(entity =>
        {
            entity.HasKey(media => media.MediaId);
            entity.Property(media => media.MediaType).HasMaxLength(20).IsRequired();
            entity.HasOne(media => media.Place).WithMany(place => place.Media).HasForeignKey(media => media.PlaceId);
        });
    }

    private static void ConfigureTrips(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Trip>(entity =>
        {
            entity.HasKey(trip => trip.TripId);
            entity.Property(trip => trip.Title).HasMaxLength(180).IsRequired();
            entity.Property(trip => trip.TripType).HasMaxLength(60).IsRequired();
            entity.Property(trip => trip.Status).HasMaxLength(40).IsRequired();
        });

        modelBuilder.Entity<TripPlace>(entity =>
        {
            entity.HasKey(tripPlace => tripPlace.TripPlaceId);
            entity.HasOne(tripPlace => tripPlace.Trip).WithMany(trip => trip.TripPlaces).HasForeignKey(tripPlace => tripPlace.TripId);
            entity.HasOne(tripPlace => tripPlace.Place).WithMany().HasForeignKey(tripPlace => tripPlace.PlaceId);
            entity.HasIndex(tripPlace => new { tripPlace.TripId, tripPlace.VisitOrder }).IsUnique();
        });

        modelBuilder.Entity<UserTrip>(entity =>
        {
            entity.HasKey(userTrip => userTrip.UserTripId);
            entity.HasIndex(userTrip => new { userTrip.UserId, userTrip.TripId }).IsUnique();
            entity.HasOne<User>().WithMany().HasForeignKey(userTrip => userTrip.UserId);
            entity.HasOne(userTrip => userTrip.Trip).WithMany().HasForeignKey(userTrip => userTrip.TripId);
        });

        modelBuilder.Entity<QuestTemplate>(entity =>
        {
            entity.HasKey(template => template.QuestTemplateId);
            entity.Property(template => template.Title).HasMaxLength(180).IsRequired();
        });

        modelBuilder.Entity<TripQuest>(entity =>
        {
            entity.HasKey(quest => quest.TripQuestId);
            entity.HasOne(quest => quest.Place).WithMany().HasForeignKey(quest => quest.PlaceId);
            entity.HasOne(quest => quest.QuestTemplate).WithMany().HasForeignKey(quest => quest.QuestTemplateId);
        });
    }

    private static void ConfigureEngagement(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<UserQuest>().HasKey(item => item.UserQuestId);
        modelBuilder.Entity<SavedPlace>().HasIndex(saved => new { saved.UserId, saved.PlaceId }).IsUnique();
        modelBuilder.Entity<SavedPlace>().HasKey(item => item.SavedPlaceId);
        modelBuilder.Entity<CustomTrip>().HasKey(item => item.CustomTripId);
        modelBuilder.Entity<CustomTripPlace>().HasIndex(place => new { place.CustomTripId, place.VisitOrder }).IsUnique();
        modelBuilder.Entity<CustomTripPlace>().HasIndex(place => new { place.CustomTripId, place.PlaceId }).IsUnique();
        modelBuilder.Entity<CustomTripPlace>().HasKey(item => item.CustomTripPlaceId);
        modelBuilder.Entity<CustomTripPlace>()
            .HasOne(item => item.CustomTrip)
            .WithMany(item => item.Places)
            .HasForeignKey(item => item.CustomTripId);
        modelBuilder.Entity<CustomTripPlace>()
            .HasOne(item => item.Place)
            .WithMany()
            .HasForeignKey(item => item.PlaceId);
        modelBuilder.Entity<Visit>().HasKey(item => item.VisitId);
        modelBuilder.Entity<VisitPhoto>().HasKey(item => item.PhotoId);
        modelBuilder.Entity<AIVerification>().HasKey(item => item.VerificationId);
        modelBuilder.Entity<Review>().HasKey(item => item.ReviewId);
        modelBuilder.Entity<PermitRequest>().HasKey(item => item.PermitRequestId);
        modelBuilder.Entity<Chat>().HasKey(item => item.ChatId);
        modelBuilder.Entity<ChatMember>().HasKey(item => item.ChatMemberId);
        modelBuilder.Entity<Message>().HasKey(item => item.MessageId);
        modelBuilder.Entity<Report>().HasKey(item => item.ReportId);
        modelBuilder.Entity<Block>().HasIndex(block => new { block.BlockerUserId, block.BlockedUserId }).IsUnique();
        modelBuilder.Entity<Block>().HasKey(item => item.BlockId);
        modelBuilder.Entity<DeviceToken>().HasKey(item => item.DeviceTokenId);
        modelBuilder.Entity<Sticker>().HasKey(item => item.StickerId);
        modelBuilder.Entity<UserSticker>().HasIndex(item => new { item.UserId, item.StickerId }).IsUnique();
        modelBuilder.Entity<UserSticker>().HasKey(item => item.UserStickerId);
        modelBuilder.Entity<Badge>().HasKey(item => item.BadgeId);
        modelBuilder.Entity<UserBadge>().HasIndex(item => new { item.UserId, item.BadgeId }).IsUnique();
        modelBuilder.Entity<UserBadge>().HasKey(item => item.UserBadgeId);
        modelBuilder.Entity<EgyptianPhrase>().HasKey(item => item.PhraseId);
        modelBuilder.Entity<UserPhrase>().HasIndex(item => new { item.UserId, item.PhraseId }).IsUnique();
        modelBuilder.Entity<UserPhrase>().HasKey(item => item.UserPhraseId);
        modelBuilder.Entity<QuizQuestion>().HasKey(item => item.QuestionId);
        modelBuilder.Entity<RewardItem>().HasKey(item => item.RewardId);
        modelBuilder.Entity<RewardRedemption>().HasKey(item => item.RedemptionId);
        modelBuilder.Entity<Notification>().HasKey(item => item.NotificationId);
        modelBuilder.Entity<PointTransaction>().HasKey(item => item.TransactionId);
    }
}
