using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;
using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.Trips;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Infrastructure.Trips;

public sealed class EfTripRepository(TourixDbContext dbContext) : ITripRepository
{
    private static readonly string[] VerifiedVisitStatuses =
    [
        "Verified",
        "Approved",
        "Completed",
    ];

    public async Task<IReadOnlyList<Trip>> GetPublishedTripsAsync(
        CancellationToken cancellationToken)
    {
        return await dbContext.Trips
            .AsNoTracking()
            .Include(trip => trip.TripPlaces)
            .Where(trip => trip.Status == "Published")
            .OrderBy(trip => trip.Title)
            .ToListAsync(cancellationToken);
    }

    public Task<Trip?> GetPublishedTripAsync(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return dbContext.Trips
            .AsNoTracking()
            .Include(trip => trip.TripPlaces)
                .ThenInclude(tripPlace => tripPlace.Place)
                    .ThenInclude(place => place!.City)
            .Where(trip => trip.Status == "Published" && trip.TripId == tripId)
            .SingleOrDefaultAsync(cancellationToken);
    }

    public Task<UserTrip?> GetUserTripAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return dbContext.UserTrips
            .AsNoTracking()
            .Include(userTrip => userTrip.Trip)
                .ThenInclude(trip => trip!.TripPlaces)
                    .ThenInclude(tripPlace => tripPlace.Place)
                        .ThenInclude(place => place!.City)
            .SingleOrDefaultAsync(
                userTrip => userTrip.UserId == userId && userTrip.TripId == tripId,
                cancellationToken);
    }

    public Task<UserTrip?> GetCurrentUserTripAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        return dbContext.UserTrips
            .AsNoTracking()
            .Include(userTrip => userTrip.Trip)
                .ThenInclude(trip => trip!.TripPlaces)
                    .ThenInclude(tripPlace => tripPlace.Place)
                        .ThenInclude(place => place!.City)
            .Where(userTrip => userTrip.UserId == userId && userTrip.Status == "InProgress")
            .OrderByDescending(userTrip => userTrip.StartedAt)
            .FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<UserTrip>> GetUserTripsAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        return await dbContext.UserTrips
            .AsNoTracking()
            .Include(userTrip => userTrip.Trip)
                .ThenInclude(trip => trip!.TripPlaces)
            .Where(userTrip => userTrip.UserId == userId)
            .OrderByDescending(userTrip => userTrip.StartedAt)
            .ToListAsync(cancellationToken);
    }

    public Task<User?> GetUserAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        return dbContext.Users.SingleOrDefaultAsync(user => user.Id == userId, cancellationToken);
    }

    public Task<bool> UserTripExistsAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return dbContext.UserTrips.AnyAsync(
            userTrip => userTrip.UserId == userId && userTrip.TripId == tripId,
            cancellationToken);
    }

    public async Task<IReadOnlyList<int>> GetVerifiedVisitOrdersAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return await dbContext.Visits
            .AsNoTracking()
            .Where(visit =>
                visit.UserId == userId &&
                visit.TripId == tripId &&
                VerifiedVisitStatuses.Contains(visit.VerificationStatus))
            .Select(visit => visit.RouteOrder)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Guid>> GetVerifiedVisitPlaceIdsAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return await dbContext.Visits
            .AsNoTracking()
            .Where(visit =>
                visit.UserId == userId &&
                visit.TripId == tripId &&
                VerifiedVisitStatuses.Contains(visit.VerificationStatus))
            .Select(visit => visit.PlaceId)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Guid>> GetRequiredQuestIdsAsync(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        return await dbContext.TripQuests
            .AsNoTracking()
            .Where(quest =>
                quest.ContextType == "Trip" &&
                quest.ContextId == tripId &&
                quest.Status == "Active")
            .Select(quest => quest.TripQuestId)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Guid>> GetCompletedQuestIdsAsync(
        Guid userId,
        IReadOnlyCollection<Guid> questIds,
        CancellationToken cancellationToken)
    {
        if (questIds.Count == 0)
        {
            return Array.Empty<Guid>();
        }

        return await dbContext.UserQuests
            .AsNoTracking()
            .Where(userQuest =>
                userQuest.UserId == userId &&
                questIds.Contains(userQuest.TripQuestId) &&
                userQuest.Status == "Completed")
            .Select(userQuest => userQuest.TripQuestId)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Badge>> GetEligibleBadgesAsync(
        Guid userId,
        int totalPointsAfterTrip,
        CancellationToken cancellationToken)
    {
        return await dbContext.Badges
            .AsNoTracking()
            .Where(badge =>
                badge.RequiredPoints <= totalPointsAfterTrip &&
                !dbContext.UserBadges.Any(userBadge =>
                    userBadge.UserId == userId &&
                    userBadge.BadgeId == badge.BadgeId))
            .OrderBy(badge => badge.RequiredPoints)
            .ToListAsync(cancellationToken);
    }

    public async Task StartUserTripAsync(
        UserTrip userTrip,
        CancellationToken cancellationToken)
    {
        dbContext.UserTrips.Add(userTrip);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task<bool> CompleteUserTripAsync(
        Guid userId,
        Guid tripId,
        int points,
        IReadOnlyCollection<Badge> badges,
        DateTimeOffset completedAt,
        CancellationToken cancellationToken)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync(cancellationToken);

        var userTrip = await dbContext.UserTrips
            .SingleOrDefaultAsync(
                item => item.UserId == userId && item.TripId == tripId,
                cancellationToken);

        var user = await dbContext.Users
            .SingleOrDefaultAsync(item => item.Id == userId, cancellationToken);

        if (userTrip is null || user is null || userTrip.Status != "InProgress")
        {
            return false;
        }

        userTrip.Status = "Completed";
        userTrip.CompletedAt = completedAt;
        userTrip.ProgressPercentage = 100;
        userTrip.TotalEarnedPoints = points;

        user.AwardPoints(points);
        dbContext.PointTransactions.Add(new PointTransaction
        {
            TransactionId = Guid.NewGuid(),
            UserId = userId,
            SourceType = "Trip",
            SourceId = tripId,
            Points = points,
            TransactionType = "Earn",
            Description = $"Completed trip: {tripId}",
            BalanceAfterTransaction = user.TotalPoints,
            CreatedAt = completedAt,
        });

        foreach (var badge in badges)
        {
            var alreadyUnlocked = await dbContext.UserBadges.AnyAsync(
                userBadge => userBadge.UserId == userId && userBadge.BadgeId == badge.BadgeId,
                cancellationToken);

            if (alreadyUnlocked)
            {
                continue;
            }

            dbContext.UserBadges.Add(new UserBadge
            {
                UserBadgeId = Guid.NewGuid(),
                UserId = userId,
                BadgeId = badge.BadgeId,
                EarnedDate = completedAt,
                Status = "Earned",
            });
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return true;
    }
}