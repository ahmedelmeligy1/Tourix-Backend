using System.Collections.Concurrent;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Infrastructure.Users;

public sealed class InMemoryUserRepository : IUserRepository
{
    private readonly ConcurrentDictionary<Guid, User> _usersById = new();
    private readonly ConcurrentDictionary<string, Guid> _idsByEmail = new(StringComparer.OrdinalIgnoreCase);

    public Task AddAsync(User user, CancellationToken cancellationToken)
    {
        _usersById[user.Id] = user;
        _idsByEmail[user.Email] = user.Id;
        return Task.CompletedTask;
    }

    public Task UpdateAsync(User user, CancellationToken cancellationToken)
    {
        _usersById[user.Id] = user;
        return Task.CompletedTask;
    }

    public Task<bool> EmailExistsAsync(string email, CancellationToken cancellationToken) =>
        Task.FromResult(_idsByEmail.ContainsKey(email));

    public Task<User?> FindByEmailAsync(string email, CancellationToken cancellationToken)
    {
        if (!_idsByEmail.TryGetValue(email, out var id))
        {
            return Task.FromResult<User?>(null);
        }

        return FindByIdAsync(id, cancellationToken);
    }

    public Task<User?> FindByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        _usersById.TryGetValue(id, out var user);
        return Task.FromResult(user);
    }
}
