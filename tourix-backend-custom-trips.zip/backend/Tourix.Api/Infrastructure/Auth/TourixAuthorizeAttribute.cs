using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Tourix.Api.Application.Auth;

namespace Tourix.Api.Infrastructure.Auth;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class TourixAuthorizeAttribute : Attribute, IAsyncActionFilter
{
    public const string UserIdItemKey = "Tourix.UserId";

    public async Task OnActionExecutionAsync(
        ActionExecutingContext context,
        ActionExecutionDelegate next)
    {
        var authorization = context.HttpContext.Request.Headers.Authorization.ToString();
        var token = authorization
            .Replace("Bearer ", string.Empty, StringComparison.OrdinalIgnoreCase)
            .Trim();
        var accessTokens = context.HttpContext.RequestServices
            .GetRequiredService<IAccessTokenService>();
        var userId = accessTokens.ReadUserId(token);

        if (userId is null)
        {
            context.Result = new UnauthorizedObjectResult(new
            {
                message = "Missing or invalid access token.",
            });
            return;
        }

        context.HttpContext.Items[UserIdItemKey] = userId.Value;
        await next();
    }
}