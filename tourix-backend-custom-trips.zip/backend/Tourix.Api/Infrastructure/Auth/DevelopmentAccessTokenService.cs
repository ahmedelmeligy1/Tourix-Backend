using System.Text;
using System.Text.Json;
using Tourix.Api.Application.Auth;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Infrastructure.Auth;

public sealed class DevelopmentAccessTokenService : IAccessTokenService
{
    public string CreateToken(User user)
    {
        var payload = new TokenPayload(user.Id, DateTimeOffset.UtcNow.AddHours(8));
        var json = JsonSerializer.Serialize(payload);
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    public Guid? ReadUserId(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
        {
            return null;
        }

        try
        {
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(token));
            var payload = JsonSerializer.Deserialize<TokenPayload>(json);
            if (payload is null || payload.ExpiresAt <= DateTimeOffset.UtcNow)
            {
                return null;
            }

            return payload.UserId;
        }
        catch (FormatException)
        {
            return null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private sealed record TokenPayload(Guid UserId, DateTimeOffset ExpiresAt);
}
