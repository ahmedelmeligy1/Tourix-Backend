using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;
using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.CustomTrips;

namespace Tourix.Api.Infrastructure.CustomTrips;

public sealed class EfCustomTripRepository(TourixDbContext dbContext) : ICustomTripRepository
{
    public Task<CustomTrip?> GetAsync(
        Guid userId,
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        return dbContext.CustomTrips
            .AsNoTracking()
            .Include(trip => trip.Places.OrderBy(place => place.VisitOrder))
                .ThenInclude(place => place.Place)
                    .ThenInclude(place => place!.City)
            .SingleOrDefaultAsync(
                trip => trip.UserId == userId && trip.CustomTripId == customTripId,
                cancellationToken);
    }

    public async Task<IReadOnlyList<CustomTrip>> GetByUserAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        return await dbContext.CustomTrips
            .AsNoTracking()
            .Include(trip => trip.Places.OrderBy(place => place.VisitOrder))
                .ThenInclude(place => place.Place)
                    .ThenInclude(place => place!.City)
            .Where(trip => trip.UserId == userId)
            .OrderByDescending(trip => trip.CreatedAt)
            .ToListAsync(cancellationToken);
    }

    public Task<Place?> GetPlaceAsync(
        Guid placeId,
        CancellationToken cancellationToken)
    {
        return dbContext.Places
            .AsNoTracking()
            .Include(place => place.City)
            .SingleOrDefaultAsync(place => place.PlaceId == placeId, cancellationToken);
    }

    public Task<bool> CustomTripPlaceExistsAsync(
        Guid customTripId,
        Guid placeId,
        CancellationToken cancellationToken)
    {
        return dbContext.CustomTripPlaces.AnyAsync(
            item => item.CustomTripId == customTripId && item.PlaceId == placeId,
            cancellationToken);
    }

    public async Task<int> GetNextVisitOrderAsync(
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var maxOrder = await dbContext.CustomTripPlaces
            .Where(item => item.CustomTripId == customTripId)
            .Select(item => (int?)item.VisitOrder)
            .MaxAsync(cancellationToken);
        return (maxOrder ?? 0) + 1;
    }

    public async Task AddAsync(
        CustomTrip customTrip,
        CancellationToken cancellationToken)
    {
        dbContext.CustomTrips.Add(customTrip);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task AddPlaceAsync(
        CustomTripPlace customTripPlace,
        CancellationToken cancellationToken)
    {
        dbContext.CustomTripPlaces.Add(customTripPlace);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task RemovePlaceAsync(
        CustomTripPlace customTripPlace,
        CancellationToken cancellationToken)
    {
        dbContext.CustomTripPlaces.Remove(customTripPlace);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateAsync(
        CustomTrip customTrip,
        CancellationToken cancellationToken)
    {
        dbContext.CustomTrips.Update(customTrip);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(
        CustomTrip customTrip,
        CancellationToken cancellationToken)
    {
        var places = await dbContext.CustomTripPlaces
            .Where(item => item.CustomTripId == customTrip.CustomTripId)
            .ToListAsync(cancellationToken);
        dbContext.CustomTripPlaces.RemoveRange(places);
        dbContext.CustomTrips.Remove(customTrip);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken) =>
        dbContext.SaveChangesAsync(cancellationToken);

    public async Task ReorderAsync(
        Guid customTripId,
        IReadOnlyList<Guid> placeIds,
        CancellationToken cancellationToken)
    {
        var places = await dbContext.CustomTripPlaces
            .Where(item => item.CustomTripId == customTripId)
            .ToListAsync(cancellationToken);

        var orderByPlaceId = placeIds
            .Select((placeId, index) => new { placeId, order = index + 1 })
            .ToDictionary(item => item.placeId, item => item.order);

        foreach (var place in places.OrderBy(place => place.VisitOrder))
        {
            place.VisitOrder = -(place.VisitOrder + 1);
        }

        await dbContext.SaveChangesAsync(cancellationToken);

        foreach (var place in places)
        {
            place.VisitOrder = orderByPlaceId[place.PlaceId];
        }

        await dbContext.SaveChangesAsync(cancellationToken);
    }
}