using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Auth;
using Tourix.Api.Contracts.Auth;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(AuthService authService) : ControllerBase
{
    // Creates a new explorer account for the Flutter signup screen.
    [HttpPost("register")]
    public async Task<IResult> Register(
        RegisterRequest request,
        CancellationToken cancellationToken)
    {
        var result = await authService.RegisterAsync(request, cancellationToken);
        return result.ToHttpResult();
    }

    // Validates explorer credentials and returns an access token.
    [HttpPost("login")]
    public async Task<IResult> Login(
        LoginRequest request,
        CancellationToken cancellationToken)
    {
        var result = await authService.LoginAsync(request, cancellationToken);
        return result.ToHttpResult();
    }

    [HttpPost("social-login")]
    public async Task<IResult> SocialLogin(
        SocialLoginRequest request,
        CancellationToken cancellationToken)
    {
        var result = await authService.SocialLoginAsync(request, cancellationToken);
        return result.ToHttpResult();
    }

    // Accepts password reset requests without exposing registered emails.
    [HttpPost("forgot-password")]
    public async Task<IResult> ForgotPassword(
        ForgotPasswordRequest request,
        CancellationToken cancellationToken)
    {
        var result = await authService.ForgotPasswordAsync(request, cancellationToken);
        return result.ToHttpResult();
    }

    // Returns the logged-in explorer profile from the bearer token.
    [HttpGet("me")]
    public async Task<IResult> Me(CancellationToken cancellationToken)
    {
        var bearerToken = Request.Headers.Authorization.ToString();
        var result = await authService.GetCurrentUserAsync(bearerToken, cancellationToken);
        return result.ToHttpResult();
    }
}
