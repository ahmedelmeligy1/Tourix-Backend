using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Trips;
using Tourix.Api.Contracts.Trips;
using Tourix.Api.Infrastructure.Auth;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/ai/generate-trip")]
public sealed class TripsController(
    TripPlanningService tripPlanningService,
    TripsService tripsService) : ControllerBase
{
    [HttpGet("recent")]
    public async Task<IActionResult> Recent(CancellationToken cancellationToken) =>
        Ok(await tripPlanningService.GetRecentTripsAsync(cancellationToken));

    [HttpPost]
    public async Task<IActionResult> Generate(TripPreferencesRequest request, CancellationToken cancellationToken) =>
        Ok(await tripPlanningService.GenerateTripAsync(request, cancellationToken));

    [HttpGet("~/api/trips")]
    public async Task<IActionResult> GetPublishedTrips(
        CancellationToken cancellationToken)
    {
        var result = await tripsService.GetPublishedTripsAsync(cancellationToken);
        return ToActionResult(result);
    }

    [HttpGet("~/api/trips/{tripId:guid}")]
    public async Task<IActionResult> GetTrip(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var result = await tripsService.GetTripAsync(tripId, cancellationToken);
        return ToActionResult(result);
    }

    [TourixAuthorize]
    [HttpPost("~/api/trips/{tripId:guid}/start")]
    public async Task<IActionResult> StartTrip(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var userId = GetAuthenticatedUserId();
        if (userId is null)
        {
            return Unauthorized(new { message = "Missing or invalid access token." });
        }

        var result = await tripsService.StartTripAsync(
            userId.Value,
            tripId,
            cancellationToken);
        return ToActionResult(result);
    }

    [TourixAuthorize]
    [HttpGet("~/api/trips/current")]
    public async Task<IActionResult> GetCurrentTrip(
        CancellationToken cancellationToken)
    {
        var userId = GetAuthenticatedUserId();
        if (userId is null)
        {
            return Unauthorized(new { message = "Missing or invalid access token." });
        }

        var result = await tripsService.GetCurrentTripAsync(
            userId.Value,
            cancellationToken);
        return ToActionResult(result);
    }

    [TourixAuthorize]
    [HttpPost("~/api/trips/{tripId:guid}/complete")]
    public async Task<IActionResult> CompleteTrip(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var userId = GetAuthenticatedUserId();
        if (userId is null)
        {
            return Unauthorized(new { message = "Missing or invalid access token." });
        }

        var result = await tripsService.CompleteTripAsync(
            userId.Value,
            tripId,
            cancellationToken);
        return ToActionResult(result);
    }

    [TourixAuthorize]
    [HttpGet("~/api/trips/my")]
    public async Task<IActionResult> GetMyTrips(
        CancellationToken cancellationToken)
    {
        var userId = GetAuthenticatedUserId();
        if (userId is null)
        {
            return Unauthorized(new { message = "Missing or invalid access token." });
        }

        var result = await tripsService.GetMyTripsAsync(
            userId.Value,
            cancellationToken);
        return ToActionResult(result);
    }

    private Guid? GetAuthenticatedUserId() =>
        HttpContext.Items.TryGetValue(
            TourixAuthorizeAttribute.UserIdItemKey,
            out var value) && value is Guid userId
            ? userId
            : null;

    private static IActionResult ToActionResult<T>(
        TripServiceResult<T> result)
    {
        return result.Succeeded
            ? new OkObjectResult(result.Value)
            : new ObjectResult(new { message = result.Error })
            {
                StatusCode = result.StatusCode,
            };
    }
}
