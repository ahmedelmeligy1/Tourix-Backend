using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Engagement;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/engagement")]
public sealed class EngagementController(EngagementService engagementService) : ControllerBase
{
    [HttpPost("saved-places/{placeId:guid}")]
    public async Task<IActionResult> SavePlace(Guid placeId, CancellationToken cancellationToken)
    {
        await engagementService.SavePlaceAsync(placeId, cancellationToken);
        return Ok(new { message = "Place saved." });
    }

    [HttpGet("notifications")]
    public async Task<IActionResult> Notifications(CancellationToken cancellationToken) =>
        Ok(await engagementService.GetNotificationsAsync(cancellationToken));
}
