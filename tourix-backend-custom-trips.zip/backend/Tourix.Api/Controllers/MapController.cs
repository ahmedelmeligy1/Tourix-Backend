using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Maps;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/map")]
public sealed class MapController(MapService mapService) : ControllerBase
{
    [HttpGet("places")]
    public async Task<IActionResult> GetPlaces(CancellationToken cancellationToken) =>
        Ok(await mapService.GetMapPlacesAsync(cancellationToken));
}
