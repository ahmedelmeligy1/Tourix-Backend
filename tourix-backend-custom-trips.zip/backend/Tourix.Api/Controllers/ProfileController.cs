using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Profile;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/profile")]
public sealed class ProfileController(ProfileService profileService) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetProfile(CancellationToken cancellationToken) =>
        Ok(await profileService.GetProfileAsync(cancellationToken));
}
