using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Quests;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/quests")]
public sealed class QuestsController(QuestService questService) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetQuests(CancellationToken cancellationToken) =>
        Ok(await questService.GetQuestsAsync(cancellationToken));
}
