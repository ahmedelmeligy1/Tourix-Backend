using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/catalog")]
public sealed class CatalogController(TourixDbContext dbContext) : ControllerBase
{
    // Gives testers one endpoint to confirm SQL Server seed data is loaded.
    [HttpGet("bootstrap")]
    public async Task<IActionResult> Bootstrap(CancellationToken cancellationToken)
    {
        var cities = await dbContext.Cities
            .Include(city => city.Places)
            .Select(city => new
            {
                city.CityId,
                city.Name,
                city.Country,
                Places = city.Places.Select(place => new
                {
                    place.PlaceId,
                    place.Name,
                    place.Category,
                    place.TicketPrice,
                    place.CoverImage,
                }),
            })
            .ToListAsync(cancellationToken);

        var trips = await dbContext.Trips
            .Select(trip => new
            {
                trip.TripId,
                trip.Title,
                trip.TripType,
                trip.EstimatedDuration,
                trip.TotalPoints,
                trip.Status,
            })
            .ToListAsync(cancellationToken);

        var rewards = await dbContext.RewardItems
            .Select(reward => new
            {
                reward.RewardId,
                reward.Title,
                reward.PointsCost,
                reward.PartnerName,
                reward.Status,
            })
            .ToListAsync(cancellationToken);

        return Ok(new { cities, trips, rewards });
    }
}
