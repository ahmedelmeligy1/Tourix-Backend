using Microsoft.AspNetCore.Mvc;

namespace Tourix.Api.Controllers;

[ApiController]
public sealed class HealthController : ControllerBase
{
    // Friendly root endpoint so opening localhost in a browser shows useful API status.
    [HttpGet("/")]
    public IActionResult Index()
    {
        return Ok(new
        {
            service = "Tourix API",
            status = "Running",
            healthUrl = "/api/health",
            authBaseUrl = "/api/auth",
            endpoints = new[]
            {
                "POST /api/auth/register",
                "POST /api/auth/login",
                "POST /api/auth/forgot-password",
                "GET /api/auth/me",
            },
        });
    }

    // Operational health endpoint for backend and deployment checks.
    [HttpGet("api/health")]
    public IActionResult Health()
    {
        return Ok(new
        {
            service = "Tourix API",
            status = "Healthy",
            utcTime = DateTimeOffset.UtcNow,
        });
    }
}
