using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.Destinations;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api")]
public sealed class DestinationsController(DestinationService destinationService) : ControllerBase
{
    [HttpGet("destinations")]
    public async Task<IActionResult> GetDestinations(CancellationToken cancellationToken) =>
        Ok(await destinationService.GetDestinationsAsync(cancellationToken));

    [HttpGet("places/{placeId:guid}")]
    public async Task<IActionResult> GetPlace(Guid placeId, CancellationToken cancellationToken)
    {
        var place = await destinationService.GetPlaceDetailsAsync(placeId, cancellationToken);
        if (place is null)
        {
            return NotFound(new { message = "Place was not found." });
        }

        return Ok(place);
    }
}
