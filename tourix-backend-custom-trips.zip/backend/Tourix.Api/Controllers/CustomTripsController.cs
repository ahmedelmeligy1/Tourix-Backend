using Microsoft.AspNetCore.Mvc;
using Tourix.Api.Application.CustomTrips;
using Tourix.Api.Contracts.CustomTrips;
using Tourix.Api.Infrastructure.Auth;

namespace Tourix.Api.Controllers;

[ApiController]
[Route("api/custom-trips")]
[TourixAuthorize]
public sealed class CustomTripsController(CustomTripsService customTripsService) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create(
        CreateCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.CreateAsync(
            GetUserId(),
            request,
            cancellationToken);
        return ToActionResult(result);
    }

    [HttpPost("{customTripId:guid}/places")]
    public async Task<IActionResult> AddPlace(
        Guid customTripId,
        AddCustomTripPlaceRequest request,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.AddPlaceAsync(
            GetUserId(),
            customTripId,
            request,
            cancellationToken);
        return ToActionResult(result);
    }

    [HttpDelete("{customTripId:guid}/places/{placeId:guid}")]
    public async Task<IActionResult> RemovePlace(
        Guid customTripId,
        Guid placeId,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.RemovePlaceAsync(
            GetUserId(),
            customTripId,
            placeId,
            cancellationToken);
        return ToActionResult(result);
    }

    [HttpPut("{customTripId:guid}/reorder")]
    public async Task<IActionResult> Reorder(
        Guid customTripId,
        ReorderCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.ReorderAsync(
            GetUserId(),
            customTripId,
            request,
            cancellationToken);
        return ToActionResult(result);
    }

    [HttpPut("{customTripId:guid}")]
    public async Task<IActionResult> Update(
        Guid customTripId,
        UpdateCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.UpdateAsync(
            GetUserId(),
            customTripId,
            request,
            cancellationToken);
        return ToActionResult(result);
    }

    [HttpDelete("{customTripId:guid}")]
    public async Task<IActionResult> Delete(
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.DeleteAsync(
            GetUserId(),
            customTripId,
            cancellationToken);
        return result.Succeeded ? NoContent() : ToActionResult(result);
    }

    [HttpPost("{customTripId:guid}/start")]
    public async Task<IActionResult> Start(
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var result = await customTripsService.StartAsync(
            GetUserId(),
            customTripId,
            cancellationToken);
        return ToActionResult(result);
    }

    private Guid GetUserId() =>
        HttpContext.Items.TryGetValue(
            TourixAuthorizeAttribute.UserIdItemKey,
            out var value) && value is Guid userId
            ? userId
            : throw new InvalidOperationException("Authenticated user ID was not set.");

    private static IActionResult ToActionResult<T>(CustomTripResult<T> result)
    {
        if (result.Succeeded)
        {
            return result.StatusCode == StatusCodes.Status201Created
                ? new ObjectResult(result.Value) { StatusCode = result.StatusCode }
                : new OkObjectResult(result.Value);
        }

        return new ObjectResult(new { message = result.Error })
        {
            StatusCode = result.StatusCode,
        };
    }
}