using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;

namespace Tourix.Api.Application.Profile;

public sealed class ProfileService(TourixDbContext dbContext)
{
    public async Task<object> GetProfileAsync(CancellationToken cancellationToken)
    {
        var user = await dbContext.Users.AsNoTracking()
            .OrderByDescending(item => item.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        return new
        {
            fullName = user?.FullName ?? "Tourix Explorer",
            email = user?.Email ?? "explorer@tourix.app",
            level = user?.Level ?? 1,
            xp = user?.Xp ?? 0,
            totalPoints = user?.TotalPoints ?? 0,
            savedPlaces = await dbContext.SavedPlaces.CountAsync(cancellationToken),
            availableRewards = await dbContext.RewardItems.CountAsync(cancellationToken),
            activeQuests = await dbContext.TripQuests.CountAsync(cancellationToken),
        };
    }
}
