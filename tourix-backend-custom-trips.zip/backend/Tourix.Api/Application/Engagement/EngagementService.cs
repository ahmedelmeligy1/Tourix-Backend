using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;
using Tourix.Api.Database.Entities;

namespace Tourix.Api.Application.Engagement;

public sealed class EngagementService(TourixDbContext dbContext)
{
    public async Task SavePlaceAsync(Guid placeId, CancellationToken cancellationToken)
    {
        var user = await dbContext.Users.OrderByDescending(item => item.CreatedAt).FirstOrDefaultAsync(cancellationToken);
        if (user is null) return;

        var exists = await dbContext.SavedPlaces.AnyAsync(
            item => item.UserId == user.Id && item.PlaceId == placeId,
            cancellationToken);
        if (exists) return;

        dbContext.SavedPlaces.Add(new SavedPlace
        {
            SavedPlaceId = Guid.NewGuid(),
            UserId = user.Id,
            PlaceId = placeId,
            SavedAt = DateTimeOffset.UtcNow,
        });
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<object>> GetNotificationsAsync(CancellationToken cancellationToken)
    {
        if (!await dbContext.Notifications.AnyAsync(cancellationToken))
        {
            return new object[]
            {
                new { title = "Welcome to Tourix", body = "Your live backend is connected to SQL Server.", type = "System" },
                new { title = "Quest Ready", body = "New location quests are available from the backend.", type = "Quest" },
            };
        }

        return await dbContext.Notifications.AsNoTracking()
            .OrderByDescending(item => item.CreatedAt)
            .Select(item => new { item.Title, item.Body, item.Type, item.IsRead, item.CreatedAt })
            .Cast<object>()
            .ToListAsync(cancellationToken);
    }
}
