using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;

namespace Tourix.Api.Application.Maps;

public sealed class MapService(TourixDbContext dbContext)
{
    public async Task<IReadOnlyList<object>> GetMapPlacesAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Places.AsNoTracking()
            .Include(place => place.City)
            .Where(place => place.Status == "Active")
            .Select(place => new
            {
                id = place.PlaceId.ToString(),
                place.Name,
                city = place.City!.Name,
                place.Category,
                place.Latitude,
                place.Longitude,
                place.GeofenceRadius,
            })
            .Cast<object>()
            .ToListAsync(cancellationToken);
    }
}
