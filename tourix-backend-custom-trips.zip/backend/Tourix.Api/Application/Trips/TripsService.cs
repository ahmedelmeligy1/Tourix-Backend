using Microsoft.EntityFrameworkCore;
using Tourix.Api.Contracts.Trips;
using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.Trips;

namespace Tourix.Api.Application.Trips;

public sealed class TripsService(ITripRepository trips)
{
    public async Task<TripServiceResult<IReadOnlyList<TripSummaryResponse>>> GetPublishedTripsAsync(
        CancellationToken cancellationToken)
    {
        var publishedTrips = await trips.GetPublishedTripsAsync(cancellationToken);
        var response = publishedTrips
            .Select(trip => new TripSummaryResponse(
                trip.TripId,
                trip.Title,
                trip.Description,
                trip.TripType,
                trip.EstimatedDuration,
                trip.TotalPoints,
                trip.DifficultyLevel,
                trip.CoverImage,
                trip.TripPlaces.Count))
            .ToList();

        return TripServiceResult<IReadOnlyList<TripSummaryResponse>>.Success(response);
    }

    public async Task<TripServiceResult<TripDetailsResponse>> GetTripAsync(
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var trip = await trips.GetPublishedTripAsync(tripId, cancellationToken);
        return trip is null
            ? TripServiceResult<TripDetailsResponse>.Failure(
                "Trip was not found.",
                StatusCodes.Status404NotFound)
            : TripServiceResult<TripDetailsResponse>.Success(ToDetailsResponse(trip));
    }

    public async Task<TripServiceResult<UserTripResponse>> StartTripAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var trip = await trips.GetPublishedTripAsync(tripId, cancellationToken);
        if (trip is null)
        {
            return TripServiceResult<UserTripResponse>.Failure(
                "Trip was not found.",
                StatusCodes.Status404NotFound);
        }

        if (await trips.UserTripExistsAsync(userId, tripId, cancellationToken))
        {
            return TripServiceResult<UserTripResponse>.Failure(
                "This trip has already been started.",
                StatusCodes.Status409Conflict);
        }

        var startedAt = DateTimeOffset.UtcNow;
        var userTrip = new UserTrip
        {
            UserTripId = Guid.NewGuid(),
            UserId = userId,
            TripId = tripId,
            StartedAt = startedAt,
            ProgressPercentage = 0,
            TotalEarnedPoints = 0,
            Status = "InProgress",
        };

        try
        {
            await trips.StartUserTripAsync(userTrip, cancellationToken);
        }
        catch (DbUpdateException)
        {
            return TripServiceResult<UserTripResponse>.Failure(
                "This trip has already been started.",
                StatusCodes.Status409Conflict);
        }

        return TripServiceResult<UserTripResponse>.Success(
            ToUserTripResponse(userTrip, 0));
    }

    public async Task<TripServiceResult<CurrentTripResponse>> GetCurrentTripAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        var userTrip = await trips.GetCurrentUserTripAsync(userId, cancellationToken);
        if (userTrip?.Trip is null)
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "There is no active trip.",
                StatusCodes.Status404NotFound);
        }

        var visitOrders = await trips.GetVerifiedVisitOrdersAsync(
            userId,
            userTrip.TripId,
            cancellationToken);
        return TripServiceResult<CurrentTripResponse>.Success(
            ToCurrentResponse(userTrip, visitOrders));
    }

    public async Task<TripServiceResult<CurrentTripResponse>> CompleteTripAsync(
        Guid userId,
        Guid tripId,
        CancellationToken cancellationToken)
    {
        var userTrip = await trips.GetUserTripAsync(userId, tripId, cancellationToken);
        if (userTrip?.Trip is null)
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "Trip was not started by this user.",
                StatusCodes.Status404NotFound);
        }

        if (userTrip.Status == "Completed")
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "This trip has already been completed.",
                StatusCodes.Status409Conflict);
        }

        if (userTrip.Status != "InProgress")
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "This trip is not in progress.",
                StatusCodes.Status409Conflict);
        }

        var visitOrders = await trips.GetVerifiedVisitOrdersAsync(
            userId,
            tripId,
            cancellationToken);
        var visitedPlaceIds = await trips.GetVerifiedVisitPlaceIdsAsync(
            userId,
            tripId,
            cancellationToken);
        var requiredOrders = userTrip.Trip.TripPlaces
            .Select(tripPlace => tripPlace.VisitOrder)
            .ToHashSet();
        var requiredPlaceIds = userTrip.Trip.TripPlaces
            .Select(tripPlace => tripPlace.PlaceId)
            .ToHashSet();

        if (!requiredOrders.IsSubsetOf(visitOrders) ||
            !requiredPlaceIds.IsSubsetOf(visitedPlaceIds))
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "Every place in the trip must be visited before it can be completed.",
                StatusCodes.Status409Conflict);
        }

        var requiredQuestIds = await trips.GetRequiredQuestIdsAsync(tripId, cancellationToken);
        var completedQuestIds = await trips.GetCompletedQuestIdsAsync(
            userId,
            requiredQuestIds,
            cancellationToken);

        if (!requiredQuestIds.All(completedQuestIds.Contains))
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "Complete all required quests before completing this trip.",
                StatusCodes.Status409Conflict);
        }

        var user = await trips.GetUserAsync(userId, cancellationToken);
        if (user is null)
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "User was not found.",
                StatusCodes.Status404NotFound);
        }

        var completedAt = DateTimeOffset.UtcNow;
        var totalPointsAfterTrip = checked(user.TotalPoints + userTrip.Trip.TotalPoints);
        var badges = await trips.GetEligibleBadgesAsync(
            userId,
            totalPointsAfterTrip,
            cancellationToken);

        var completed = await trips.CompleteUserTripAsync(
            userId,
            tripId,
            userTrip.Trip.TotalPoints,
            badges,
            completedAt,
            cancellationToken);

        if (!completed)
        {
            return TripServiceResult<CurrentTripResponse>.Failure(
                "This trip can no longer be completed.",
                StatusCodes.Status409Conflict);
        }

        userTrip.Status = "Completed";
        userTrip.CompletedAt = completedAt;
        userTrip.ProgressPercentage = 100;
        userTrip.TotalEarnedPoints = userTrip.Trip.TotalPoints;

        return TripServiceResult<CurrentTripResponse>.Success(
            ToCurrentResponse(userTrip, visitOrders));
    }

    public async Task<TripServiceResult<IReadOnlyList<UserTripResponse>>> GetMyTripsAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        var userTrips = await trips.GetUserTripsAsync(userId, cancellationToken);
        var response = new List<UserTripResponse>(userTrips.Count);

        foreach (var userTrip in userTrips)
        {
            var visitOrders = userTrip.Status == "Completed"
                ? Array.Empty<int>()
                : await trips.GetVerifiedVisitOrdersAsync(
                    userId,
                    userTrip.TripId,
                    cancellationToken);
            response.Add(ToUserTripResponse(userTrip, visitOrders.Count(
                order => userTrip.Trip?.TripPlaces.Any(place => place.VisitOrder == order) == true)));
        }

        return TripServiceResult<IReadOnlyList<UserTripResponse>>.Success(response);
    }

    private static TripDetailsResponse ToDetailsResponse(Trip trip)
    {
        return new TripDetailsResponse(
            trip.TripId,
            trip.Title,
            trip.Description,
            trip.TripType,
            trip.EstimatedDuration,
            trip.TotalPoints,
            trip.DifficultyLevel,
            trip.CoverImage,
            trip.TripPlaces
                .OrderBy(tripPlace => tripPlace.VisitOrder)
                .Select(ToPlaceResponse)
                .ToList());
    }

    private static CurrentTripResponse ToCurrentResponse(
        UserTrip userTrip,
        IReadOnlyCollection<int> visitOrders)
    {
        var orderedPlaces = userTrip.Trip!.TripPlaces
            .OrderBy(tripPlace => tripPlace.VisitOrder)
            .ToList();
        var completedCount = orderedPlaces.Count(place => visitOrders.Contains(place.VisitOrder));
        var percentage = orderedPlaces.Count == 0
            ? 100
            : (int)Math.Round(completedCount * 100d / orderedPlaces.Count);
        var currentIndex = orderedPlaces.FindIndex(
            place => !visitOrders.Contains(place.VisitOrder));

        var currentPlace = currentIndex >= 0
            ? ToPlaceResponse(orderedPlaces[currentIndex])
            : null;
        var nextPlace = currentIndex >= 0 && currentIndex + 1 < orderedPlaces.Count
            ? ToPlaceResponse(orderedPlaces[currentIndex + 1])
            : null;

        return new CurrentTripResponse(
            ToUserTripResponse(userTrip, completedCount),
            currentPlace,
            nextPlace,
            percentage);
    }

    private static UserTripResponse ToUserTripResponse(UserTrip userTrip, int progress)
    {
        var tripProgress = userTrip.Status == "Completed" ? 100 : progress;
        return new UserTripResponse(
            userTrip.UserTripId,
            userTrip.TripId,
            userTrip.Status,
            tripProgress,
            userTrip.StartedAt,
            userTrip.CompletedAt,
            userTrip.TotalEarnedPoints);
    }

    private static TripPlaceResponse ToPlaceResponse(TripPlace tripPlace)
    {
        var place = tripPlace.Place!;
        return new TripPlaceResponse(
            tripPlace.VisitOrder,
            place.PlaceId,
            place.Name,
            place.Description,
            place.City?.Name,
            place.Latitude,
            place.Longitude,
            tripPlace.EstimatedStayTime,
            place.AverageVisitDuration,
            place.CoverImage);
    }
}