using Microsoft.EntityFrameworkCore;
using Tourix.Api.Contracts.Trips;
using Tourix.Api.Database;
using Tourix.Api.Database.Entities;

namespace Tourix.Api.Application.Trips;

public sealed class TripPlanningService(TourixDbContext dbContext)
{
    private static readonly Guid SystemAdminId = Guid.Parse("11111111-1111-1111-1111-111111111111");

    public async Task<IReadOnlyList<object>> GetRecentTripsAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Trips.AsNoTracking()
            .Where(trip => trip.Status == "Published")
            .OrderByDescending(trip => trip.TotalPoints)
            .Select(trip => new
            {
                id = trip.TripId.ToString(),
                title = trip.Title,
                location = "Egypt",
                imageUrl = trip.CoverImage,
                score = trip.TotalPoints / 180.0,
                durationDays = trip.EstimatedDuration,
                budget = trip.EstimatedDuration * 950.0,
            })
            .Cast<object>()
            .ToListAsync(cancellationToken);
    }

    public async Task<object> GenerateTripAsync(TripPreferencesRequest request, CancellationToken cancellationToken)
    {
        var firstCity = await dbContext.Cities.AsNoTracking().FirstAsync(cancellationToken);
        var trip = new Trip
        {
            TripId = Guid.NewGuid(),
            Title = string.IsNullOrWhiteSpace(request.Destination)
                ? "Personal Egypt Discovery"
                : $"{request.Destination} Discovery Plan",
            Description = $"Generated Tourix plan for {request.TravelStyle} travelers.",
            TripType = request.TravelStyle,
            EstimatedDuration = ParseDuration(request.Duration),
            TotalPoints = 1200,
            DifficultyLevel = "Easy",
            CoverImage = firstCity.CoverImage,
            Status = "Published",
            CreatedByAdminId = SystemAdminId,
            UpdatedByAdminId = SystemAdminId,
            CreatedAt = DateTimeOffset.UtcNow,
        };

        dbContext.Trips.Add(trip);
        await dbContext.SaveChangesAsync(cancellationToken);

        return new
        {
            id = trip.TripId.ToString(),
            title = trip.Title,
            location = string.IsNullOrWhiteSpace(request.Destination) ? "Egypt" : request.Destination,
            imageUrl = trip.CoverImage,
            score = 9.2,
            durationDays = trip.EstimatedDuration,
            budget = request.BudgetRange?.End ?? 3500,
        };
    }

    private static int ParseDuration(string? duration)
    {
        if (string.IsNullOrWhiteSpace(duration)) return 3;

        var digits = new string(duration.Where(char.IsDigit).ToArray());
        return int.TryParse(digits, out var days) && days > 0 ? days : 3;
    }
}
