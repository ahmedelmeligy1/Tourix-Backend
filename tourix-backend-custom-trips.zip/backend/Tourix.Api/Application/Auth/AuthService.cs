using Tourix.Api.Contracts.Auth;
using Tourix.Api.Domain.Users;

namespace Tourix.Api.Application.Auth;

public sealed class AuthService(
    IUserRepository users,
    IPasswordHasher passwordHasher,
    IAccessTokenService accessTokens)
{
    public async Task<AuthResult<AuthResponse>> RegisterAsync(
        RegisterRequest request,
        CancellationToken cancellationToken)
    {
        var validationError = ValidateRegistration(request);
        if (validationError is not null)
        {
            return AuthResult<AuthResponse>.Failure(validationError, StatusCodes.Status400BadRequest);
        }

        if (await users.EmailExistsAsync(request.Email, cancellationToken))
        {
            return AuthResult<AuthResponse>.Failure("Email is already registered.", StatusCodes.Status409Conflict);
        }

        var user = User.Create(
            request.FullName.Trim(),
            request.Email.Trim().ToLowerInvariant(),
            passwordHasher.Hash(request.Password));

        await users.AddAsync(user, cancellationToken);

        return AuthResult<AuthResponse>.Success(CreateAuthResponse(user), StatusCodes.Status201Created);
    }

    public async Task<AuthResult<AuthResponse>> LoginAsync(
        LoginRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
        {
            return AuthResult<AuthResponse>.Failure("Email and password are required.", StatusCodes.Status400BadRequest);
        }

        var user = await users.FindByEmailAsync(request.Email.Trim().ToLowerInvariant(), cancellationToken);
        if (user is null || !passwordHasher.Verify(request.Password, user.PasswordHash))
        {
            return AuthResult<AuthResponse>.Failure("Invalid email or password.", StatusCodes.Status401Unauthorized);
        }

        user.MarkLoggedIn();
        await users.UpdateAsync(user, cancellationToken);

        return AuthResult<AuthResponse>.Success(CreateAuthResponse(user));
    }

    public async Task<AuthResult<AuthResponse>> SocialLoginAsync(
        SocialLoginRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Provider))
        {
            return AuthResult<AuthResponse>.Failure("Auth provider is required.", StatusCodes.Status400BadRequest);
        }

        var email = string.IsNullOrWhiteSpace(request.Email)
            ? $"{request.Provider.ToLowerInvariant()}@tourix.social"
            : request.Email.Trim().ToLowerInvariant();

        var user = await users.FindByEmailAsync(email, cancellationToken);
        if (user is null)
        {
            user = User.Create(
                string.IsNullOrWhiteSpace(request.FullName) ? $"{request.Provider} Explorer" : request.FullName.Trim(),
                email,
                passwordHasher.Hash(Guid.NewGuid().ToString("N")));
            await users.AddAsync(user, cancellationToken);
        }

        user.MarkLoggedIn();
        await users.UpdateAsync(user, cancellationToken);

        return AuthResult<AuthResponse>.Success(CreateAuthResponse(user));
    }

    public Task<AuthResult<MessageResponse>> ForgotPasswordAsync(
        ForgotPasswordRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Email))
        {
            return Task.FromResult(
                AuthResult<MessageResponse>.Failure("Email is required.", StatusCodes.Status400BadRequest));
        }

        // Temporary competition flow: avoid revealing whether the email exists.
        var response = new MessageResponse("If this email exists, a password reset link will be sent.");
        return Task.FromResult(AuthResult<MessageResponse>.Success(response));
    }

    public async Task<AuthResult<UserProfileResponse>> GetCurrentUserAsync(
        string authorizationHeader,
        CancellationToken cancellationToken)
    {
        var token = authorizationHeader.Replace("Bearer ", string.Empty, StringComparison.OrdinalIgnoreCase).Trim();
        var userId = accessTokens.ReadUserId(token);
        if (userId is null)
        {
            return AuthResult<UserProfileResponse>.Failure("Missing or invalid access token.", StatusCodes.Status401Unauthorized);
        }

        var user = await users.FindByIdAsync(userId.Value, cancellationToken);
        if (user is null)
        {
            return AuthResult<UserProfileResponse>.Failure("User was not found.", StatusCodes.Status404NotFound);
        }

        return AuthResult<UserProfileResponse>.Success(UserProfileResponse.FromUser(user));
    }

    private AuthResponse CreateAuthResponse(User user)
    {
        var token = accessTokens.CreateToken(user);
        return new AuthResponse(token, UserProfileResponse.FromUser(user));
    }

    private static string? ValidateRegistration(RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.FullName))
        {
            return "Full name is required.";
        }

        if (string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@'))
        {
            return "A valid email is required.";
        }

        if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length < 8)
        {
            return "Password must be at least 8 characters.";
        }

        return null;
    }
}
