namespace Tourix.Api.Application.Auth;

public sealed record AuthResult<T>(bool IsSuccess, T? Value, string? Error, int StatusCode)
{
    public static AuthResult<T> Success(T value, int statusCode = StatusCodes.Status200OK) =>
        new(true, value, null, statusCode);

    public static AuthResult<T> Failure(string error, int statusCode) =>
        new(false, default, error, statusCode);

    public IResult ToHttpResult()
    {
        if (IsSuccess)
        {
            return Results.Json(Value, statusCode: StatusCode);
        }

        return Results.Json(new { message = Error }, statusCode: StatusCode);
    }
}
