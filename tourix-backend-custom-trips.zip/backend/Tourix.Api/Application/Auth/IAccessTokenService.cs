using Tourix.Api.Domain.Users;

namespace Tourix.Api.Application.Auth;

public interface IAccessTokenService
{
    string CreateToken(User user);

    Guid? ReadUserId(string token);
}
