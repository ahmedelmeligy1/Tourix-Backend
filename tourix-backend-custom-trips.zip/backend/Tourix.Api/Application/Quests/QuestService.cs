using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;

namespace Tourix.Api.Application.Quests;

public sealed class QuestService(TourixDbContext dbContext)
{
    public async Task<IReadOnlyList<object>> GetQuestsAsync(CancellationToken cancellationToken)
    {
        return await dbContext.TripQuests.AsNoTracking()
            .Include(quest => quest.Place)
            .Include(quest => quest.QuestTemplate)
            .Select(quest => new
            {
                id = quest.TripQuestId.ToString(),
                title = quest.QuestTemplate!.Title,
                description = quest.QuestTemplate.Description,
                placeName = quest.Place!.Name,
                questType = quest.QuestTemplate.QuestType,
                rewardPoints = quest.QuestTemplate.RewardPoints,
                status = quest.Status,
            })
            .Cast<object>()
            .ToListAsync(cancellationToken);
    }
}
