using Microsoft.EntityFrameworkCore;
using Tourix.Api.Contracts.CustomTrips;
using Tourix.Api.Database.Entities;
using Tourix.Api.Domain.CustomTrips;

namespace Tourix.Api.Application.CustomTrips;

public sealed class CustomTripsService(ICustomTripRepository customTrips)
{
    public async Task<CustomTripResult<CustomTripResponse>> CreateAsync(
        Guid userId,
        CreateCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var validationError = ValidateDates(request.StartDate, request.EndDate);
        if (validationError is not null)
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                validationError,
                StatusCodes.Status400BadRequest);
        }

        var now = DateTimeOffset.UtcNow;
        var customTrip = new CustomTrip
        {
            CustomTripId = Guid.NewGuid(),
            UserId = userId,
            Title = request.Title!.Trim(),
            StartDate = request.StartDate,
            EndDate = request.EndDate,
            TotalDays = CalculateTotalDays(request.StartDate, request.EndDate),
            Status = "Draft",
            CreatedAt = now,
        };

        await customTrips.AddAsync(customTrip, cancellationToken);
        return CustomTripResult<CustomTripResponse>.Created(ToResponse(customTrip));
    }

    public async Task<CustomTripResult<CustomTripResponse>> AddPlaceAsync(
        Guid userId,
        Guid customTripId,
        AddCustomTripPlaceRequest request,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        var place = await customTrips.GetPlaceAsync(request.PlaceId, cancellationToken);
        if (place is null)
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "Place was not found.",
                StatusCodes.Status404NotFound);
        }

        if (await customTrips.CustomTripPlaceExistsAsync(
                customTripId,
                request.PlaceId,
                cancellationToken))
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "This place is already in the custom trip.",
                StatusCodes.Status409Conflict);
        }

        customTrip.Places.Add(new CustomTripPlace
        {
            CustomTripPlaceId = Guid.NewGuid(),
            CustomTripId = customTripId,
            PlaceId = request.PlaceId,
            VisitOrder = await customTrips.GetNextVisitOrderAsync(
                customTripId,
                cancellationToken),
            EstimatedDuration = place.AverageVisitDuration,
        });

        try
        {
            await customTrips.AddPlaceAsync(customTrip.Places.Last(), cancellationToken);
        }
        catch (DbUpdateException)
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "This place is already in the custom trip.",
                StatusCodes.Status409Conflict);
        }

        return await GetAsync(userId, customTripId, cancellationToken);
    }

    public async Task<CustomTripResult<CustomTripResponse>> RemovePlaceAsync(
        Guid userId,
        Guid customTripId,
        Guid placeId,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        var place = customTrip.Places.SingleOrDefault(item => item.PlaceId == placeId);
        if (place is null)
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "Place is not part of this custom trip.",
                StatusCodes.Status404NotFound);
        }

        await customTrips.RemovePlaceAsync(place, cancellationToken);
        await customTrips.ReorderAsync(
            customTripId,
            customTrip.Places
                .Where(item => item.PlaceId != placeId)
                .OrderBy(item => item.VisitOrder)
                .Select(item => item.PlaceId)
                .ToList(),
            cancellationToken);
        return await GetAsync(userId, customTripId, cancellationToken);
    }

    public async Task<CustomTripResult<CustomTripResponse>> ReorderAsync(
        Guid userId,
        Guid customTripId,
        ReorderCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        var placeIds = request.PlaceIds ?? Array.Empty<Guid>();
        var existingPlaceIds = customTrip.Places.Select(place => place.PlaceId).ToHashSet();
        var requestedPlaceIds = placeIds.ToHashSet();

        if (placeIds.Count != requestedPlaceIds.Count ||
            !existingPlaceIds.SetEquals(requestedPlaceIds))
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "The reorder list must contain every place in this custom trip exactly once.",
                StatusCodes.Status400BadRequest);
        }

        await customTrips.ReorderAsync(customTripId, placeIds, cancellationToken);
        return await GetAsync(userId, customTripId, cancellationToken);
    }

    public async Task<CustomTripResult<CustomTripResponse>> UpdateAsync(
        Guid userId,
        Guid customTripId,
        UpdateCustomTripRequest request,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        var startDate = request.StartDate ?? customTrip.StartDate;
        var endDate = request.EndDate ?? customTrip.EndDate;
        var validationError = ValidateDates(startDate, endDate);
        if (validationError is not null)
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                validationError,
                StatusCodes.Status400BadRequest);
        }

        if (request.Title is not null)
        {
            if (string.IsNullOrWhiteSpace(request.Title))
            {
                return CustomTripResult<CustomTripResponse>.Failure(
                    "Title cannot be empty.",
                    StatusCodes.Status400BadRequest);
            }

            customTrip.Title = request.Title.Trim();
        }

        customTrip.StartDate = startDate;
        customTrip.EndDate = endDate;
        customTrip.TotalDays = CalculateTotalDays(startDate, endDate);
        customTrip.UpdatedAt = DateTimeOffset.UtcNow;

        await customTrips.UpdateAsync(customTrip, cancellationToken);
        return await GetAsync(userId, customTripId, cancellationToken);
    }

    public async Task<CustomTripResult<CustomTripResponse>> DeleteAsync(
        Guid userId,
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        await customTrips.DeleteAsync(customTrip, cancellationToken);
        return CustomTripResult<CustomTripResponse>.Success(null!);
    }

    public async Task<CustomTripResult<CustomTripResponse>> StartAsync(
        Guid userId,
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        if (customTrip is null)
        {
            return NotFound();
        }

        if (customTrip.Status is "Active" or "Completed")
        {
            return CustomTripResult<CustomTripResponse>.Failure(
                "An active or completed custom trip cannot be started again.",
                StatusCodes.Status409Conflict);
        }

        customTrip.Status = "Active";
        customTrip.UpdatedAt = DateTimeOffset.UtcNow;
        await customTrips.UpdateAsync(customTrip, cancellationToken);
        return await GetAsync(userId, customTripId, cancellationToken);
    }

    private async Task<CustomTripResult<CustomTripResponse>> GetAsync(
        Guid userId,
        Guid customTripId,
        CancellationToken cancellationToken)
    {
        var customTrip = await customTrips.GetAsync(userId, customTripId, cancellationToken);
        return customTrip is null
            ? NotFound()
            : CustomTripResult<CustomTripResponse>.Success(ToResponse(customTrip));
    }

    private static CustomTripResponse ToResponse(CustomTrip customTrip) =>
        new(
            customTrip.CustomTripId,
            customTrip.Title,
            customTrip.StartDate,
            customTrip.EndDate,
            customTrip.TotalDays,
            customTrip.Status,
            customTrip.CreatedAt,
            customTrip.UpdatedAt,
            customTrip.Places
                .OrderBy(place => place.VisitOrder)
                .Select(place => new CustomTripPlaceResponse(
                    place.PlaceId,
                    place.Place?.Name ?? string.Empty,
                    place.Place?.Description ?? string.Empty,
                    place.Place?.City?.Name,
                    place.VisitOrder,
                    place.PlannedVisitDate,
                    place.EstimatedDuration,
                    place.Place?.CoverImage))
                .ToList());

    private static string? ValidateDates(DateOnly? startDate, DateOnly? endDate)
    {
        if (startDate.HasValue && endDate.HasValue && endDate < startDate)
        {
            return "End date must be on or after start date.";
        }

        return null;
    }

    private static int CalculateTotalDays(DateOnly? startDate, DateOnly? endDate) =>
        startDate.HasValue && endDate.HasValue
            ? endDate.Value.DayNumber - startDate.Value.DayNumber + 1
            : 0;

    private static CustomTripResult<CustomTripResponse> NotFound() =>
        CustomTripResult<CustomTripResponse>.Failure(
            "Custom trip was not found.",
            StatusCodes.Status404NotFound);
}