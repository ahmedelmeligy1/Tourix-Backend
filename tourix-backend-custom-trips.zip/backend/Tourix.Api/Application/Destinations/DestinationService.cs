using Microsoft.EntityFrameworkCore;
using Tourix.Api.Database;

namespace Tourix.Api.Application.Destinations;

public sealed class DestinationService(TourixDbContext dbContext)
{
    public async Task<IReadOnlyList<object>> GetDestinationsAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Places.AsNoTracking()
            .Include(place => place.City)
            .Where(place => place.Status == "Active")
            .OrderBy(place => place.City!.Name)
            .ThenBy(place => place.Name)
            .Select(place => new
            {
                id = place.PlaceId.ToString(),
                place.Name,
                location = place.City!.Name + ", " + place.City.Country,
                imageUrl = place.CoverImage,
                rating = 4.7,
                reviewsCount = 128,
                place.Category,
                shortDescription = place.Description,
                distanceKm = place.City.Name == "Cairo" || place.City.Name == "Giza" ? 18 : 650,
                tag = place.Category == "Historical" ? "AI RECOMMENDED" : null,
            })
            .Cast<object>()
            .ToListAsync(cancellationToken);
    }

    public async Task<object?> GetPlaceDetailsAsync(Guid placeId, CancellationToken cancellationToken)
    {
        var place = await dbContext.Places.AsNoTracking()
            .Include(item => item.City)
            .FirstOrDefaultAsync(item => item.PlaceId == placeId, cancellationToken);

        if (place is null) return null;

        var nearby = await dbContext.Places.AsNoTracking()
            .Where(item => item.CityId == place.CityId && item.PlaceId != place.PlaceId)
            .Take(3)
            .Select(item => new
            {
                id = item.PlaceId.ToString(),
                item.Name,
                imageUrl = item.CoverImage,
                distanceKm = 2.4,
            })
            .ToListAsync(cancellationToken);

        return new
        {
            id = place.PlaceId.ToString(),
            place.Name,
            location = place.City!.Name + ", " + place.City.Country,
            heroImageUrl = place.CoverImage,
            rating = 4.8,
            priceLabel = $"{place.TicketPrice:0} EGP",
            sectionTitle = place.Category + " Experience",
            place.Description,
            oracleWisdom = "Arrive early, keep your camera ready, and follow the marked route for the best Tourix score.",
            openingHours = $"{place.OpeningHours:HH:mm} - {place.ClosingHours:HH:mm}",
            bestTime = "Early Morning",
            nearbyPlaces = nearby,
        };
    }
}
