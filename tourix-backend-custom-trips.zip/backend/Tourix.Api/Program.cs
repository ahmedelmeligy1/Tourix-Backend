using Microsoft.EntityFrameworkCore;
using Tourix.Api.Application.Auth;
using Tourix.Api.Application.CustomTrips;
using Tourix.Api.Application.Destinations;
using Tourix.Api.Application.Engagement;
using Tourix.Api.Application.Maps;
using Tourix.Api.Application.Profile;
using Tourix.Api.Application.Quests;
using Tourix.Api.Application.Trips;
using Tourix.Api.Database;
using Tourix.Api.Domain.Trips;
using Tourix.Api.Domain.CustomTrips;
using Tourix.Api.Domain.Users;
using Tourix.Api.Infrastructure.Auth;
using Tourix.Api.Infrastructure.CustomTrips;
using Tourix.Api.Infrastructure.Trips;
using Tourix.Api.Infrastructure.Users;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<TourixDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TourixDatabase")));

// Cross-origin access for the Flutter app during local development.
builder.Services.AddCors(options =>
{
    options.AddPolicy("FlutterLocalDev", policy =>
        policy.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod());
});

// Authentication module dependencies.
builder.Services.AddScoped<IUserRepository, EfUserRepository>();
builder.Services.AddSingleton<IPasswordHasher, PasswordHasher>();
builder.Services.AddSingleton<IAccessTokenService, DevelopmentAccessTokenService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<DestinationService>();
builder.Services.AddScoped<EngagementService>();
builder.Services.AddScoped<MapService>();
builder.Services.AddScoped<QuestService>();
builder.Services.AddScoped<ProfileService>();
builder.Services.AddScoped<TripPlanningService>();
builder.Services.AddScoped<ITripRepository, EfTripRepository>();
builder.Services.AddScoped<TripsService>();
builder.Services.AddScoped<ICustomTripRepository, EfCustomTripRepository>();
builder.Services.AddScoped<CustomTripsService>();

var app = builder.Build();

app.UseCors("FlutterLocalDev");
app.UseSwagger();
app.UseSwaggerUI();

using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<TourixDbContext>();
    await dbContext.Database.EnsureCreatedAsync();
    await TourixDbSeeder.SeedAsync(dbContext);
}

app.MapControllers();

app.Run();
